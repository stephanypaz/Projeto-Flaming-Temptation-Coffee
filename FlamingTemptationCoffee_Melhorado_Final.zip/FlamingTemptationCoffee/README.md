# Instruções para o Sistema Flaming Temptation Coffee (Refatorado)

## Estrutura do Projeto
O projeto foi refatorado seguindo os princípios de organização em pacotes:

- **model**: Classes que representam as entidades do sistema
- **view**: Classes que simulam o "front-end" do programa (usando System.out e Scanner)
- **interfaces**: Interfaces que definem contratos implementados por outras classes

## Conceitos de POO Aplicados
- **Herança**: Classe abstrata `Produto` com subclasses `Bebida` e `Alimento`
- **Polimorfismo**: Método `calcularDesconto()` implementado de formas diferentes nas subclasses
- **Sobrecarga**: Múltiplos construtores em várias classes (ex: `ItemPedido`)
- **Sobrescrita**: Método `toString()` sobrescrito em várias classes
- **Classes Abstratas**: `Produto` como classe abstrata base
- **Interfaces**: `CRUD<T>`, `GerenciamentoProdutos` e `GerenciamentoPedidos`

## Requisitos para Execução
- Java Development Kit (JDK) instalado no computador

## Como Compilar o Código
1. Navegue até a pasta raiz do projeto
2. Execute o comando: `javac -d bin src/interfaces/*.java src/model/*.java src/view/*.java`

## Como Executar o Sistema
1. Após compilar, execute o comando: `java -cp bin view.FlamingTemptationCoffeeView`

## Funcionalidades do Sistema
- **Visualizar Menu**: Exibe todos os produtos disponíveis organizados por categorias
- **Fazer Pedido**: Permite selecionar produtos, definir quantidades e adicionar observações
- **Visualizar Carrinho**: Mostra os itens adicionados, permite remover itens ou alterar quantidades
- **Finalizar Pedido**: Coleta informações do cliente e forma de pagamento para concluir a compra
- **Consultar Pedidos**: Exibe os pedidos realizados e permite atualizar o status

## Documentação
Todas as classes e métodos possuem documentação JavaDoc detalhada explicando suas funções e parâmetros.
