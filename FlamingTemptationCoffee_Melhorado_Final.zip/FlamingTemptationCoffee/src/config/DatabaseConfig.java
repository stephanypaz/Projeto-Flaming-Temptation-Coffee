package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Classe responsável pela configuração e gerenciamento da conexão com o banco de dados.
 * Implementa o padrão Singleton para garantir uma única instância de conexão.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 * @since 1.1
 */
public class DatabaseConfig {
    /** URL de conexão com o banco de dados H2 em memória */
    private static final String URL = "jdbc:h2:mem:flamingdb;DB_CLOSE_DELAY=-1";
    /** Usuário do banco de dados */
    private static final String USER = "sa";
    /** Senha do banco de dados */
    private static final String PASSWORD = "";
    /** Instância única da classe (padrão Singleton) */
    private static DatabaseConfig instance;
    /** Conexão com o banco de dados */
    private Connection connection;
    
    /**
     * Construtor privado para implementar o padrão Singleton.
     * Inicializa a conexão com o banco de dados e cria as tabelas necessárias.
     */
    private DatabaseConfig() {
        try {
            // Carrega o driver JDBC do H2
            Class.forName("org.h2.Driver");
            
            // Estabelece a conexão
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            
            // Cria as tabelas se não existirem
            createTables();
            
            System.out.println("Conexão com banco de dados estabelecida com sucesso!");
        } catch (ClassNotFoundException e) {
            System.err.println("Driver JDBC do H2 não encontrado: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Erro ao conectar ao banco de dados: " + e.getMessage());
        }
    }
    
    /**
     * Retorna a instância única da classe DatabaseConfig.
     * 
     * @return Instância de DatabaseConfig
     */
    public static synchronized DatabaseConfig getInstance() {
        if (instance == null) {
            instance = new DatabaseConfig();
        }
        return instance;
    }
    
    /**
     * Retorna a conexão com o banco de dados.
     * 
     * @return Conexão com o banco de dados
     * @throws SQLException se a conexão estiver fechada ou inválida
     */
    public Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        }
        return connection;
    }
    
    /**
     * Fecha a conexão com o banco de dados.
     */
    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Conexão com banco de dados fechada com sucesso!");
            } catch (SQLException e) {
                System.err.println("Erro ao fechar conexão com banco de dados: " + e.getMessage());
            }
        }
    }
    
    /**
     * Cria as tabelas necessárias no banco de dados.
     * 
     * @throws SQLException se ocorrer um erro durante a criação das tabelas
     */
    private void createTables() throws SQLException {
        try (Statement stmt = connection.createStatement()) {
            // Tabela de Produtos
            stmt.execute("CREATE TABLE IF NOT EXISTS produtos (" +
                         "id INT PRIMARY KEY, " +
                         "nome VARCHAR(100) NOT NULL, " +
                         "descricao VARCHAR(255), " +
                         "preco DECIMAL(10,2) NOT NULL, " +
                         "categoria VARCHAR(50) NOT NULL, " +
                         "tipo VARCHAR(20) NOT NULL" +
                         ")");
            
            // Tabela de Bebidas (estende Produtos)
            stmt.execute("CREATE TABLE IF NOT EXISTS bebidas (" +
                         "id INT PRIMARY KEY, " +
                         "tamanho VARCHAR(20) NOT NULL, " +
                         "quente BOOLEAN NOT NULL, " +
                         "FOREIGN KEY (id) REFERENCES produtos(id)" +
                         ")");
            
            // Tabela de Alimentos (estende Produtos)
            stmt.execute("CREATE TABLE IF NOT EXISTS alimentos (" +
                         "id INT PRIMARY KEY, " +
                         "vegetariano BOOLEAN NOT NULL, " +
                         "sem_gluten BOOLEAN NOT NULL, " +
                         "FOREIGN KEY (id) REFERENCES produtos(id)" +
                         ")");
            
            // Tabela de Pedidos
            stmt.execute("CREATE TABLE IF NOT EXISTS pedidos (" +
                         "numero_pedido INT PRIMARY KEY, " +
                         "nome_cliente VARCHAR(100) NOT NULL, " +
                         "status VARCHAR(50) NOT NULL, " +
                         "forma_pagamento VARCHAR(50) NOT NULL, " +
                         "data_hora VARCHAR(50) NOT NULL" +
                         ")");
            
            // Tabela de Itens de Pedido
            stmt.execute("CREATE TABLE IF NOT EXISTS itens_pedido (" +
                         "id INT AUTO_INCREMENT PRIMARY KEY, " +
                         "numero_pedido INT NOT NULL, " +
                         "produto_id INT NOT NULL, " +
                         "quantidade INT NOT NULL, " +
                         "observacoes VARCHAR(255), " +
                         "FOREIGN KEY (numero_pedido) REFERENCES pedidos(numero_pedido), " +
                         "FOREIGN KEY (produto_id) REFERENCES produtos(id)" +
                         ")");
            
            System.out.println("Tabelas criadas com sucesso!");
        }
    }
}
