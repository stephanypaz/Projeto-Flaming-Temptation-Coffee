package view;

import java.util.Scanner;
import repository.Menu;
import repository.Carrinho;
import model.Produto;
import model.ItemPedido;
import service.ProdutoService;
import util.FormatadorTexto;
import util.Validador;
import java.util.List;

/**
 * Classe responsável pela visualização do menu e interação com produtos.
 * Simula a interface de usuário para exibição e seleção de produtos.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 */
public class MenuView {
    /** Scanner para leitura de entrada do usuário */
    private Scanner scanner;
    /** Objeto Menu com os produtos disponíveis */
    private Menu menu;
    
    /**
     * Construtor da classe MenuView.
     * 
     * @param scanner Scanner para leitura de entrada do usuário
     * @param menu Objeto Menu com os produtos disponíveis
     * @throws IllegalArgumentException se scanner ou menu forem nulos
     */
    public MenuView(Scanner scanner, Menu menu) {
        if (scanner == null || menu == null) {
            throw new IllegalArgumentException("Scanner e Menu não podem ser nulos");
        }
        this.scanner = scanner;
        this.menu = menu;
    }
    
    /**
     * Exibe o menu completo de produtos.
     * Mostra todos os produtos organizados por categoria.
     */
    public void exibirMenu() {
        System.out.println("\n" + menu.exibirMenuCompleto());
        aguardarEnter();
    }
    
    /**
     * Permite ao usuário fazer um pedido, selecionando produtos do menu.
     * Guia o usuário através do processo de seleção de categoria e produto.
     * 
     * @param carrinho Carrinho onde os itens selecionados serão adicionados
     * @throws IllegalArgumentException se o carrinho for nulo
     */
    public void fazerPedido(Carrinho carrinho) {
        if (carrinho == null) {
            throw new IllegalArgumentException("Carrinho não pode ser nulo");
        }
        
        boolean continuar = true;
        
        while (continuar) {
            System.out.println("\n" + FormatadorTexto.criarCabecalho("Fazer Pedido"));
            System.out.println("Categorias disponíveis:");
            
            String[] categorias = menu.listarCategorias();
            for (int i = 0; i < categorias.length; i++) {
                System.out.println(FormatadorTexto.formatarItemNumerado(i + 1, categorias[i]));
            }
            
            System.out.println("0. Voltar ao menu principal");
            System.out.print("\nEscolha uma categoria: ");
            
            int opcaoCategoria = lerOpcao();
            
            if (opcaoCategoria == 0) {
                continuar = false;
                continue;
            }
            
            if (opcaoCategoria < 1 || opcaoCategoria > categorias.length) {
                System.out.println("\nCategoria inválida.");
                aguardarEnter();
                continue;
            }
            
            String categoriaEscolhida = categorias[opcaoCategoria - 1];
            System.out.println("\n" + menu.listarProdutosPorCategoria(categoriaEscolhida));
            
            System.out.print("Digite o número do produto desejado (0 para voltar): ");
            int numeroLocal = lerOpcao();
            
            if (numeroLocal == 0) {
                continue;
            }
            
            // Obter a lista de produtos da categoria e selecionar pelo índice local
            List<Produto> produtosCategoria = menu.getProdutosPorCategoria(categoriaEscolhida);
            
            if (numeroLocal < 1 || numeroLocal > produtosCategoria.size()) {
                System.out.println("\nNúmero de produto inválido.");
                aguardarEnter();
                continue;
            }
            
            // Converter número local (1-based) para índice de array (0-based)
            Produto produtoEscolhido = produtosCategoria.get(numeroLocal - 1);
            
            if (produtoEscolhido == null) {
                System.out.println("\nProduto não encontrado.");
                aguardarEnter();
                continue;
            }
            
            System.out.println("\nProduto selecionado: " + produtoEscolhido.getNome());
            System.out.print("Quantidade: ");
            int quantidade = lerOpcao();
            
            if (!Validador.quantidadeValida(quantidade)) {
                System.out.println("\nQuantidade inválida.");
                aguardarEnter();
                continue;
            }
            
            System.out.print("Observações (opcional): ");
            String observacoes = scanner.nextLine();
            
            ItemPedido item = new ItemPedido(produtoEscolhido, quantidade, observacoes);
            carrinho.criar(item);
            
            System.out.println("\nProduto adicionado ao carrinho!");
            
            System.out.print("\nDeseja adicionar mais produtos? (S/N): ");
            String resposta = scanner.nextLine();
            
            if (!resposta.equalsIgnoreCase("S")) {
                continuar = false;
            }
        }
    }
    
    /**
     * Lê uma opção numérica do usuário.
     * 
     * @return Número inteiro representando a opção escolhida, ou -1 em caso de erro
     */
    private int lerOpcao() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
    
    /**
     * Aguarda o usuário pressionar ENTER para continuar.
     * Exibe uma mensagem e pausa a execução até que o usuário pressione ENTER.
     */
    private void aguardarEnter() {
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
    }
    
    /**
     * Permite ao usuário buscar produtos por nome ou descrição.
     * 
     * @return Lista de produtos encontrados
     */
    public List<Produto> buscarProdutos() {
        System.out.println("\n" + FormatadorTexto.criarCabecalho("Buscar Produtos"));
        System.out.print("Digite o termo de busca: ");
        String termo = scanner.nextLine();
        
        if (Validador.textoVazio(termo)) {
            System.out.println("\nTermo de busca inválido.");
            aguardarEnter();
            return null;
        }
        
        List<Produto> resultados = ProdutoService.buscarPorNomeOuDescricao(menu.getProdutos(), termo);
        
        if (resultados.isEmpty()) {
            System.out.println("\nNenhum produto encontrado para o termo: " + termo);
        } else {
            System.out.println("\n" + FormatadorTexto.criarCabecalho("Resultados da Busca"));
            for (int i = 0; i < resultados.size(); i++) {
                System.out.println(FormatadorTexto.formatarItemNumerado(i + 1, resultados.get(i).toString()));
            }
        }
        
        aguardarEnter();
        return resultados;
    }
}
