package view;

import java.util.Scanner;
import repository.Menu;
import repository.Carrinho;
import repository.PedidoRepository;
import model.Produto;
import model.ItemPedido;
import model.Pedido;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe principal da interface com o usuário.
 * Responsável por exibir o menu principal e coordenar as operações do sistema.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 */
public class FlamingTemptationCoffeeView {
    /** Scanner para leitura de entrada do usuário */
    private Scanner scanner;
    /** Repositório de produtos (menu) */
    private Menu menu;
    /** Carrinho de compras atual */
    private Carrinho carrinho;
    /** Repositório de pedidos */
    private PedidoRepository pedidoRepository;
    /** View para operações do menu */
    private MenuView menuView;
    /** View para operações do carrinho */
    private CarrinhoView carrinhoView;
    /** View para operações de pedidos */
    private PedidoView pedidoView;
    
    /**
     * Construtor da classe FlamingTemptationCoffeeView.
     * Inicializa os componentes do sistema e as classes de visualização.
     */
    public FlamingTemptationCoffeeView() {
        this.scanner = new Scanner(System.in);
        this.menu = new Menu();
        this.carrinho = new Carrinho();
        this.pedidoRepository = new PedidoRepository();
        this.menuView = new MenuView(scanner, menu);
        this.carrinhoView = new CarrinhoView(scanner, carrinho);
        this.pedidoView = new PedidoView(scanner, pedidoRepository, carrinho);
    }
    
    /**
     * Inicia a execução do sistema e exibe o menu principal.
     */
    public void iniciar() {
        boolean sair = false;
        
        while (!sair) {
            exibirMenuPrincipal();
            int opcao = lerOpcao();
            
            switch (opcao) {
                case 1:
                    menuView.exibirMenu();
                    break;
                case 2:
                    menuView.fazerPedido(carrinho);
                    break;
                case 3:
                    carrinhoView.exibirCarrinho();
                    break;
                case 4:
                    pedidoView.finalizarPedido();
                    break;
                case 5:
                    pedidoView.consultarPedidos();
                    break;
                case 0:
                    sair = true;
                    System.out.println("\nObrigado por utilizar o Flaming Temptation Coffee!");
                    break;
                default:
                    System.out.println("\nOpção inválida. Por favor, tente novamente.");
                    aguardarEnter();
            }
        }
    }
    
    /**
     * Exibe o menu principal do sistema.
     */
    private void exibirMenuPrincipal() {
        System.out.println("\n===== FLAMING TEMPTATION COFFEE =====");
        System.out.println("1. Visualizar Menu");
        System.out.println("2. Fazer Pedido");
        System.out.println("3. Visualizar Carrinho");
        System.out.println("4. Finalizar Pedido");
        System.out.println("5. Consultar Pedidos");
        System.out.println("0. Sair");
        System.out.print("\nEscolha uma opção: ");
    }
    
    /**
     * Lê uma opção numérica do usuário.
     * 
     * @return Número inteiro representando a opção escolhida
     */
    private int lerOpcao() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
    
    /**
     * Aguarda o usuário pressionar ENTER para continuar.
     */
    private void aguardarEnter() {
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
    }
    
    /**
     * Método principal para execução do sistema.
     * 
     * @param args Argumentos de linha de comando (não utilizados)
     */
    public static void main(String[] args) {
        FlamingTemptationCoffeeView app = new FlamingTemptationCoffeeView();
        app.iniciar();
    }
}
