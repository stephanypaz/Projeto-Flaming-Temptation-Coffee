package view;

import java.util.Scanner;
import repository.Carrinho;
import model.ItemPedido;

/**
 * Classe responsável pela visualização do carrinho e interação com itens.
 * Simula a interface de usuário para exibição e manipulação do carrinho de compras.
 */
public class CarrinhoView {
    private Scanner scanner;
    private Carrinho carrinho;
    
    /**
     * Construtor da classe CarrinhoView.
     * 
     * @param scanner Scanner para leitura de entrada do usuário
     * @param carrinho Objeto Carrinho a ser manipulado
     */
    public CarrinhoView(Scanner scanner, Carrinho carrinho) {
        this.scanner = scanner;
        this.carrinho = carrinho;
    }
    
    /**
     * Exibe o conteúdo atual do carrinho e permite manipulá-lo.
     */
    public void exibirCarrinho() {
        if (carrinho.estaVazio()) {
            System.out.println("\nO carrinho está vazio.");
            aguardarEnter();
            return;
        }
        
        System.out.println("\n" + carrinho.listarTodos());
        
        System.out.println("\nOpções:");
        System.out.println("1. Remover item");
        System.out.println("2. Alterar quantidade");
        System.out.println("0. Voltar ao menu principal");
        System.out.print("\nEscolha uma opção: ");
        
        int opcao = lerOpcao();
        
        switch (opcao) {
            case 1:
                removerItem();
                break;
            case 2:
                alterarQuantidade();
                break;
            case 0:
                return;
            default:
                System.out.println("\nOpção inválida.");
                aguardarEnter();
        }
    }
    
    /**
     * Remove um item do carrinho.
     */
    private void removerItem() {
        System.out.print("\nDigite o número do produto a ser removido: ");
        int idProduto = lerOpcao();
        
        if (carrinho.excluir(idProduto)) {
            System.out.println("\nItem removido com sucesso!");
        } else {
            System.out.println("\nProduto não encontrado no carrinho.");
        }
        
        aguardarEnter();
    }
    
    /**
     * Altera a quantidade de um item no carrinho.
     */
    private void alterarQuantidade() {
        System.out.print("\nDigite o número do produto para alterar a quantidade: ");
        int idProduto = lerOpcao();
        
        ItemPedido item = carrinho.buscar(idProduto);
        
        if (item == null) {
            System.out.println("\nProduto não encontrado no carrinho.");
            aguardarEnter();
            return;
        }
        
        System.out.println("\nProduto: " + item.getProduto().getNome());
        System.out.println("Quantidade atual: " + item.getQuantidade());
        System.out.print("Nova quantidade: ");
        
        int novaQuantidade = lerOpcao();
        
        if (novaQuantidade <= 0) {
            System.out.println("\nQuantidade inválida. O item será removido do carrinho.");
            carrinho.excluir(idProduto);
        } else {
            item.setQuantidade(novaQuantidade);
            carrinho.atualizar(idProduto, item);
            System.out.println("\nQuantidade atualizada com sucesso!");
        }
        
        aguardarEnter();
    }
    
    /**
     * Lê uma opção numérica do usuário.
     * 
     * @return Número inteiro representando a opção escolhida
     */
    private int lerOpcao() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
    
    /**
     * Aguarda o usuário pressionar ENTER para continuar.
     */
    private void aguardarEnter() {
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
    }
}
