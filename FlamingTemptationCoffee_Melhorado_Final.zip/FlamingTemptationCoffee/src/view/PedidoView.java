package view;

import java.util.Scanner;
import java.util.List;
import repository.Carrinho;
import repository.PedidoRepository;
import model.Pedido;
import model.ItemPedido;
import util.FormatadorTexto;

/**
 * Classe responsável pela visualização e gerenciamento de pedidos.
 * Simula a interface de usuário para finalização e consulta de pedidos.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 */
public class PedidoView {
    /** Scanner para leitura de entrada do usuário */
    private Scanner scanner;
    /** Repositório de pedidos */
    private PedidoRepository pedidoRepository;
    /** Carrinho atual de compras */
    private Carrinho carrinho;

    /**
     * Construtor da classe PedidoView.
     *
     * @param scanner Scanner para leitura de entrada do usuário
     * @param pedidoRepository Repositório de pedidos do sistema
     * @param carrinho Carrinho atual de compras
     */
    public PedidoView(Scanner scanner, PedidoRepository pedidoRepository, Carrinho carrinho) {
        this.scanner = scanner;
        this.pedidoRepository = pedidoRepository;
        this.carrinho = carrinho;
    }

    /**
     * Finaliza o pedido atual, coletando informações do cliente e pagamento.
     */
    public void finalizarPedido() {
        if (carrinho.estaVazio()) {
            System.out.println("\nO carrinho está vazio. Adicione produtos antes de finalizar o pedido.");
            aguardarEnter();
            return;
        }

        System.out.println("\n===== FINALIZAR PEDIDO =====");
        System.out.println(carrinho.listarTodos()); // Exibe itens e total

        System.out.print("\nNome do cliente: ");
        String nomeCliente = scanner.nextLine();

        System.out.print("Telefone: ");
        String telefone = scanner.nextLine();

        System.out.print("Endereço de entrega: ");
        String endereco = scanner.nextLine();

        String formaPagamento = null;
        boolean pagamentoConfirmado = false;

        while (!pagamentoConfirmado) {
            System.out.println("\nFormas de Pagamento:");
            System.out.println("1. Cartão de Crédito");
            System.out.println("2. Cartão de Débito");
            System.out.println("3. Dinheiro");
            System.out.println("4. PIX");
            System.out.println("0. Cancelar Pedido");
            System.out.print("Escolha a forma de pagamento: ");

            int opcaoPagamento = lerOpcao();

            switch (opcaoPagamento) {
                case 1: // Cartão de Crédito
                    System.out.println("\n--- Dados do Cartão de Crédito ---");
                    System.out.print("Número do Cartão: ");
                    String numCredito = scanner.nextLine();
                    System.out.print("Validade (MM/AA): ");
                    String valCredito = scanner.nextLine();
                    System.out.print("CVV: ");
                    String cvvCredito = scanner.nextLine();
                    System.out.print("Nome no Cartão: ");
                    String nomeCredito = scanner.nextLine();
                    // Apenas simula a coleta, não armazena de forma segura
                    formaPagamento = "Cartão de Crédito (Final: " + (numCredito.length() >= 4 ? numCredito.substring(numCredito.length() - 4) : "****") + ")";
                    pagamentoConfirmado = true;
                    break;
                case 2: // Cartão de Débito
                    System.out.println("\n--- Dados do Cartão de Débito ---");
                    System.out.print("Número do Cartão: ");
                    String numDebito = scanner.nextLine();
                    System.out.print("Validade (MM/AA): ");
                    String valDebito = scanner.nextLine();
                    System.out.print("CVV: ");
                    String cvvDebito = scanner.nextLine();
                    System.out.print("Nome no Cartão: ");
                    String nomeDebito = scanner.nextLine();
                    // Apenas simula a coleta, não armazena de forma segura
                    formaPagamento = "Cartão de Débito (Final: " + (numDebito.length() >= 4 ? numDebito.substring(numDebito.length() - 4) : "****") + ")";
                    pagamentoConfirmado = true;
                    break;
                case 3: // Dinheiro
                    formaPagamento = "Dinheiro";
                    System.out.print("Precisa de troco? (S/N): ");
                    String precisaTroco = scanner.nextLine();
                    if (precisaTroco.equalsIgnoreCase("S")) {
                        System.out.print("Troco para quanto? R$ ");
                        String valorTroco = scanner.nextLine();
                        formaPagamento += " (Troco para R$ " + valorTroco + ")";
                    }
                    pagamentoConfirmado = true;
                    break;
                case 4: // PIX
                    double valorTotal = carrinho.calcularTotal();
                    System.out.println("\n--- Pagamento PIX ---");
                    System.out.printf("Valor: R$ %.2f%n", valorTotal);
                    System.out.println("Chave Pix Telefone: 81986354492");
                    System.out.println("Nome: Matheus Henrique");
                    System.out.println("----------------------");
                    System.out.print("O valor foi pago? (S/N): ");
                    String respostaPix = scanner.nextLine();
                    if (respostaPix.equalsIgnoreCase("S")) {
                        formaPagamento = "PIX";
                        pagamentoConfirmado = true;
                    } else {
                        System.out.println("Pagamento PIX não confirmado. Escolha outra forma ou tente novamente.");
                        // O loop continuará, pedindo a forma de pagamento novamente
                    }
                    break;
                case 0: // Cancelar
                    System.out.println("\nFinalização de pedido cancelada.");
                    aguardarEnter();
                    return; // Sai do método finalizarPedido
                default:
                    System.out.println("\nOpção de pagamento inválida. Tente novamente.");
            }
        }

        // Cria o pedido com os itens do carrinho
        Pedido novoPedido = new Pedido();
        novoPedido.setNomeCliente(nomeCliente);
        novoPedido.setFormaPagamento(formaPagamento);
        novoPedido.setStatus("Recebido");
        novoPedido.setItens(carrinho.getItens());
        
        // Adiciona dados de pagamento
        novoPedido.adicionarDadoPagamento("telefone", telefone);
        novoPedido.adicionarDadoPagamento("endereco", endereco);
        
        // Salva o pedido no repositório
        pedidoRepository.criar(novoPedido);

        System.out.println("\nPedido realizado com sucesso!");
        System.out.println("Número do pedido: #" + novoPedido.getNumeroPedido());
        System.out.println("\nDetalhes do pedido:");
        System.out.println(exibirDetalhesPedido(novoPedido));

        // Limpa o carrinho após o pedido ser finalizado com sucesso
        carrinho.limpar();

        aguardarEnter();
    }

    /**
     * Consulta os pedidos realizados e permite atualizar o status.
     */
    public void consultarPedidos() {
        List<Pedido> pedidos = pedidoRepository.getPedidos();
        
        if (pedidos.isEmpty()) {
            System.out.println("\nNenhum pedido realizado ainda.");
            aguardarEnter();
            return;
        }

        System.out.println("\n===== PEDIDOS REALIZADOS =====");
        for (Pedido pedido : pedidos) {
            System.out.println("Pedido #" + pedido.getNumeroPedido() +
                              " - Cliente: " + pedido.getNomeCliente() +
                              " - Status: " + pedido.getStatus() +
                              " - Valor: R$ " + String.format("%.2f", pedido.calcularTotal()));
        }

        System.out.print("\nDigite o número do pedido para ver detalhes (0 para voltar): ");
        int numeroPedido = lerOpcao();

        if (numeroPedido > 0) {
            Pedido pedido = pedidoRepository.buscar(numeroPedido);
            
            if (pedido != null) {
                System.out.println(exibirDetalhesPedido(pedido));

                // Lógica para atualizar status
                if (pedido.getStatus().equals("Recebido")) {
                    System.out.println("\nOpções de status:");
                    System.out.println("1. Em preparo");
                    System.out.println("2. Saiu para entrega");
                    System.out.println("3. Entregue");
                    System.out.println("4. Cancelado");
                    System.out.print("Atualizar status para: ");

                    int opcaoStatus = lerOpcao();
                    switch (opcaoStatus) {
                        case 1:
                            pedidoRepository.atualizarStatus(numeroPedido, "Em preparo");
                            break;
                        case 2:
                            pedidoRepository.atualizarStatus(numeroPedido, "Saiu para entrega");
                            break;
                        case 3:
                            pedidoRepository.atualizarStatus(numeroPedido, "Entregue");
                            break;
                        case 4:
                            pedidoRepository.atualizarStatus(numeroPedido, "Cancelado");
                            break;
                        default:
                            System.out.println("Opção inválida.");
                    }

                    if (opcaoStatus >= 1 && opcaoStatus <= 4) {
                        System.out.println("Status atualizado com sucesso!");
                    }
                }
            } else {
                System.out.println("Pedido não encontrado.");
            }
        }

        aguardarEnter();
    }
    
    /**
     * Formata os detalhes de um pedido para exibição.
     * 
     * @param pedido Pedido a ser exibido
     * @return String formatada com os detalhes do pedido
     */
    private String exibirDetalhesPedido(Pedido pedido) {
        StringBuilder sb = new StringBuilder();
        sb.append(FormatadorTexto.criarCabecalho("Pedido #" + pedido.getNumeroPedido()));
        sb.append("Cliente: ").append(pedido.getNomeCliente()).append("\n");
        sb.append("Status: ").append(pedido.getStatus()).append("\n");
        sb.append("Forma de Pagamento: ").append(pedido.getFormaPagamento()).append("\n");
        sb.append("Data/Hora: ").append(pedido.getDataHora()).append("\n\n");
        
        sb.append("Itens:\n");
        List<ItemPedido> itens = pedido.getItens();
        for (int i = 0; i < itens.size(); i++) {
            ItemPedido item = itens.get(i);
            sb.append(FormatadorTexto.formatarItemNumerado(i + 1, item.toString())).append("\n");
        }
        
        sb.append("\nValor Total: ").append(FormatadorTexto.formatarMoeda(pedido.calcularTotal()));
        
        return sb.toString();
    }

    /**
     * Lê uma opção numérica do usuário.
     *
     * @return Número inteiro representando a opção escolhida
     */
    private int lerOpcao() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /**
     * Aguarda o usuário pressionar ENTER para continuar.
     */
    private void aguardarEnter() {
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
    }
}
