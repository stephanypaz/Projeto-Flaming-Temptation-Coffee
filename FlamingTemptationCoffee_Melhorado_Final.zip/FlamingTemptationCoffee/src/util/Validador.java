package util;

/**
 * Classe utilitária para validação de dados no sistema.
 * Centraliza operações de validação para garantir consistência.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 */
public class Validador {
    
    /**
     * Verifica se uma string está vazia ou nula.
     * 
     * @param texto Texto a ser verificado
     * @return true se o texto for nulo ou vazio
     */
    public static boolean textoVazio(String texto) {
        return texto == null || texto.trim().isEmpty();
    }
    
    /**
     * Verifica se um valor numérico é positivo.
     * 
     * @param valor Valor a ser verificado
     * @return true se o valor for maior que zero
     */
    public static boolean valorPositivo(double valor) {
        return valor > 0;
    }
    
    /**
     * Verifica se uma quantidade é válida (maior que zero).
     * 
     * @param quantidade Quantidade a ser verificada
     * @return true se a quantidade for válida
     */
    public static boolean quantidadeValida(int quantidade) {
        return quantidade > 0;
    }
    
    /**
     * Verifica se um ID é válido (maior que zero).
     * 
     * @param id ID a ser verificado
     * @return true se o ID for válido
     */
    public static boolean idValido(int id) {
        return id > 0;
    }
    
    /**
     * Valida um objeto, verificando se não é nulo.
     * 
     * @param objeto Objeto a ser validado
     * @return true se o objeto não for nulo
     */
    public static boolean objetoExiste(Object objeto) {
        return objeto != null;
    }
}
