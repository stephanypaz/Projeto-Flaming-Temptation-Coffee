package util;

/**
 * Classe utilitária para formatação de texto no sistema.
 * Centraliza operações de formatação para evitar duplicação de código.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 */
public class FormatadorTexto {
    
    /**
     * Formata um valor monetário para exibição.
     * 
     * @param valor Valor a ser formatado
     * @return String formatada com o valor monetário (R$ XX,XX)
     */
    public static String formatarMoeda(double valor) {
        return String.format("R$ %.2f", valor);
    }
    
    /**
     * Cria um cabeçalho formatado para seções do sistema.
     * 
     * @param titulo Título da seção
     * @return String formatada com o cabeçalho
     */
    public static String criarCabecalho(String titulo) {
        return String.format("===== %s =====\n", titulo.toUpperCase());
    }
    
    /**
     * Cria um subcabeçalho formatado para subseções do sistema.
     * 
     * @param titulo Título da subseção
     * @return String formatada com o subcabeçalho
     */
    public static String criarSubcabecalho(String titulo) {
        return String.format("\n--- %s ---\n", titulo.toUpperCase());
    }
    
    /**
     * Formata um item de lista numerada.
     * 
     * @param numero Número do item
     * @param texto Texto do item
     * @return String formatada com o item numerado
     */
    public static String formatarItemNumerado(int numero, String texto) {
        return String.format("%d. %s", numero, texto);
    }
    
    /**
     * Trunca um texto longo para exibição resumida.
     * 
     * @param texto Texto a ser truncado
     * @param tamanhoMaximo Tamanho máximo do texto resultante
     * @return Texto truncado com "..." se necessário
     */
    public static String truncarTexto(String texto, int tamanhoMaximo) {
        if (texto == null || texto.length() <= tamanhoMaximo) {
            return texto;
        }
        return texto.substring(0, tamanhoMaximo - 3) + "...";
    }
}
