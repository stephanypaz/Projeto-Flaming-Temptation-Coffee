package repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import model.Produto;
import model.Bebida;
import model.Alimento;
import util.FormatadorTexto;
import util.Validador;

/**
 * Classe que representa o menu de produtos da cafeteria.
 * Responsável por armazenar, gerenciar e fornecer acesso aos produtos disponíveis.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 */
public class Menu {
    /** Lista de produtos disponíveis no menu */
    private List<Produto> produtos;
    /** Mapa de produtos por categoria para acesso rápido */
    private Map<String, List<Produto>> produtosPorCategoria;

    /**
     * Construtor da classe Menu.
     * Inicializa a lista de produtos e o mapa de categorias, e adiciona produtos padrão.
     */
    public Menu() {
        this.produtos = new ArrayList<>();
        this.produtosPorCategoria = new HashMap<>();
        adicionarProdutosPadrao();
    }

    /**
     * Adiciona produtos padrão ao menu.
     * Popula o menu com uma seleção inicial de bebidas e alimentos.
     */
    private void adicionarProdutosPadrao() {
        // Bebidas Quentes
        adicionarProduto(new Bebida(1, "Espresso", "Café forte e encorpado", 5.00, "Bebidas Quentes", "Pequeno", true));
        adicionarProduto(new Bebida(2, "Cappuccino", "Espresso com leite vaporizado e espuma", 8.00, "Bebidas Quentes", "Médio", true));
        adicionarProduto(new Bebida(3, "Latte", "Espresso com leite vaporizado", 7.50, "Bebidas Quentes", "Grande", true));
        adicionarProduto(new Bebida(4, "Chá de Camomila", "Chá calmante de camomila", 6.00, "Bebidas Quentes", "Médio", true));
        
        // Bebidas Geladas
        adicionarProduto(new Bebida(5, "Iced Coffee", "Café gelado refrescante", 7.00, "Bebidas Geladas", "Grande", false));
        adicionarProduto(new Bebida(6, "Suco de Laranja", "Suco natural de laranja", 6.50, "Bebidas Geladas", "Médio", false));
        adicionarProduto(new Bebida(7, "Frappuccino", "Bebida gelada de café com chantilly", 10.00, "Bebidas Geladas", "Grande", false));
        
        // Alimentos
        adicionarProduto(new Alimento(8, "Croissant", "Massa folhada amanteigada", 6.00, "Alimentos", false, false));
        adicionarProduto(new Alimento(9, "Pão de Queijo", "Tradicional pão de queijo mineiro", 4.00, "Alimentos", true, false));
        adicionarProduto(new Alimento(10, "Bolo de Cenoura", "Bolo fofo de cenoura com cobertura de chocolate", 7.00, "Alimentos", false, false));
        adicionarProduto(new Alimento(11, "Sanduíche Natural", "Pão integral com peito de peru, queijo e salada", 9.00, "Alimentos", false, false));
        adicionarProduto(new Alimento(12, "Salada de Frutas", "Mix de frutas frescas da estação", 8.50, "Alimentos", true, true));
    }
    
    /**
     * Adiciona um produto ao menu e atualiza o mapa de categorias.
     * 
     * @param produto Produto a ser adicionado
     * @return true se o produto foi adicionado com sucesso
     * @throws IllegalArgumentException se o produto for nulo
     */
    public boolean adicionarProduto(Produto produto) {
        if (!Validador.objetoExiste(produto)) {
            throw new IllegalArgumentException("Produto não pode ser nulo");
        }
        
        boolean adicionado = produtos.add(produto);
        
        if (adicionado) {
            String categoria = produto.getCategoria();
            
            // Atualiza o mapa de produtos por categoria
            if (!produtosPorCategoria.containsKey(categoria)) {
                produtosPorCategoria.put(categoria, new ArrayList<>());
            }
            
            produtosPorCategoria.get(categoria).add(produto);
        }
        
        return adicionado;
    }

    /**
     * Lista todas as categorias de produtos disponíveis.
     *
     * @return Array de Strings com os nomes das categorias
     */
    public String[] listarCategorias() {
        return produtosPorCategoria.keySet().toArray(new String[0]);
    }

    /**
     * Retorna uma lista de produtos de uma categoria específica.
     *
     * @param categoria Categoria desejada
     * @return Lista de Produtos da categoria
     * @throws IllegalArgumentException se a categoria for nula ou vazia
     */
    public List<Produto> getProdutosPorCategoria(String categoria) {
        if (Validador.textoVazio(categoria)) {
            throw new IllegalArgumentException("Categoria não pode ser nula ou vazia");
        }
        
        // Se a categoria existir no mapa, retorna uma cópia da lista
        if (produtosPorCategoria.containsKey(categoria)) {
            return new ArrayList<>(produtosPorCategoria.get(categoria));
        }
        
        // Caso contrário, busca na lista completa (para categorias com diferenças de case)
        List<Produto> produtosCategoria = new ArrayList<>();
        for (Produto produto : produtos) {
            if (produto.getCategoria().equalsIgnoreCase(categoria)) {
                produtosCategoria.add(produto);
            }
        }
        
        return produtosCategoria;
    }

    /**
     * Lista produtos por uma categoria específica (formato String para exibição).
     * Utiliza numeração local (1, 2, 3...) para cada categoria.
     *
     * @param categoria Categoria desejada
     * @return Representação textual dos produtos da categoria com numeração local
     * @throws IllegalArgumentException se a categoria for nula ou vazia
     */
    public String listarProdutosPorCategoria(String categoria) {
        if (Validador.textoVazio(categoria)) {
            throw new IllegalArgumentException("Categoria não pode ser nula ou vazia");
        }
        
        List<Produto> produtosCategoria = getProdutosPorCategoria(categoria);
        StringBuilder sb = new StringBuilder();
        sb.append(FormatadorTexto.criarCabecalho(categoria));

        if (produtosCategoria.isEmpty()) {
            sb.append("Nenhum produto encontrado nesta categoria.\n");
        } else {
            for (int i = 0; i < produtosCategoria.size(); i++) {
                Produto produto = produtosCategoria.get(i);
                // Usa (i + 1) para numeração local começando em 1
                sb.append(FormatadorTexto.formatarItemNumerado(i + 1, produto.toStringSimples())).append("\n");
            }
        }
        return sb.toString();
    }

    /**
     * Retorna o menu completo formatado.
     *
     * @return String com o menu completo
     */
    public String exibirMenuCompleto() {
        if (produtos.isEmpty()) {
            return "Menu vazio.";
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append(FormatadorTexto.criarCabecalho("Menu Completo"));
        
        // Itera sobre o mapa de categorias para exibição organizada
        for (Map.Entry<String, List<Produto>> entry : produtosPorCategoria.entrySet()) {
            String categoria = entry.getKey();
            List<Produto> produtosCategoria = entry.getValue();
            
            sb.append(FormatadorTexto.criarSubcabecalho(categoria));
            
            for (Produto produto : produtosCategoria) {
                sb.append(produto.toString()).append("\n");
            }
        }
        
        return sb.toString();
    }

    /**
     * Retorna um produto pelo seu ID global.
     *
     * @param id ID global do produto
     * @return Objeto Produto ou null se não encontrado
     */
    public Produto getProdutoPorId(int id) {
        if (!Validador.idValido(id)) {
            return null;
        }
        
        for (Produto produto : produtos) {
            if (produto.getId() == id) {
                return produto;
            }
        }
        return null;
    }

    /**
     * Retorna a lista de todos os produtos.
     *
     * @return Lista de Produto (cópia defensiva)
     */
    public List<Produto> getProdutos() {
        return new ArrayList<>(produtos);
    }
    
    /**
     * Retorna o mapa de produtos organizados por categoria.
     * 
     * @return Mapa com categorias e suas listas de produtos (cópia defensiva)
     */
    public Map<String, List<Produto>> getProdutosPorCategoriaMap() {
        Map<String, List<Produto>> copia = new HashMap<>();
        
        for (Map.Entry<String, List<Produto>> entry : produtosPorCategoria.entrySet()) {
            copia.put(entry.getKey(), new ArrayList<>(entry.getValue()));
        }
        
        return copia;
    }
    
    /**
     * Remove um produto do menu pelo ID.
     * 
     * @param id ID do produto a ser removido
     * @return true se o produto foi removido com sucesso
     */
    public boolean removerProduto(int id) {
        Produto produto = getProdutoPorId(id);
        
        if (produto != null) {
            String categoria = produto.getCategoria();
            
            // Remove do mapa de categorias
            if (produtosPorCategoria.containsKey(categoria)) {
                produtosPorCategoria.get(categoria).remove(produto);
                
                // Se a lista ficou vazia, remove a categoria
                if (produtosPorCategoria.get(categoria).isEmpty()) {
                    produtosPorCategoria.remove(categoria);
                }
            }
            
            // Remove da lista principal
            return produtos.remove(produto);
        }
        
        return false;
    }
}
