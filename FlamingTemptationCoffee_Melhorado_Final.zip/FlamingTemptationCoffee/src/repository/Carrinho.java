package repository;

import java.util.ArrayList;
import java.util.List;
import interfaces.CRUD;
import model.ItemPedido;
import util.FormatadorTexto;
import util.Validador;

/**
 * Classe que representa o carrinho de compras.
 * Implementa a interface CRUD para gerenciamento dos itens no carrinho.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 */
public class Carrinho implements CRUD<ItemPedido> {
    /** Lista de itens no carrinho */
    private List<ItemPedido> itens;

    /**
     * Construtor da classe Carrinho.
     * Inicializa a lista de itens.
     */
    public Carrinho() {
        this.itens = new ArrayList<>();
    }

    /**
     * Adiciona um item ao carrinho.
     *
     * @param item Item a ser adicionado
     * @return true se o item foi adicionado com sucesso
     * @throws IllegalArgumentException se o item for nulo
     */
    @Override
    public boolean criar(ItemPedido item) {
        if (!Validador.objetoExiste(item)) {
            throw new IllegalArgumentException("Item não pode ser nulo");
        }
        return itens.add(item);
    }

    /**
     * Busca um item no carrinho pelo ID do produto.
     *
     * @param id ID do produto a ser buscado
     * @return ItemPedido encontrado ou null se não existir
     */
    @Override
    public ItemPedido buscar(int id) {
        for (ItemPedido item : itens) {
            if (item.getProduto().getId() == id) {
                return item;
            }
        }
        return null;
    }

    /**
     * Atualiza um item no carrinho.
     *
     * @param id ID do produto do item a ser atualizado
     * @param novoItem ItemPedido com as novas informações
     * @return true se o item foi atualizado com sucesso
     * @throws IllegalArgumentException se o novo item for nulo
     */
    @Override
    public boolean atualizar(int id, ItemPedido novoItem) {
        if (!Validador.objetoExiste(novoItem)) {
            throw new IllegalArgumentException("Novo item não pode ser nulo");
        }
        
        for (int i = 0; i < itens.size(); i++) {
            if (itens.get(i).getProduto().getId() == id) {
                itens.set(i, novoItem);
                return true;
            }
        }
        return false;
    }

    /**
     * Exclui um item do carrinho pelo ID do produto.
     *
     * @param id ID do produto do item a ser excluído
     * @return true se o item foi excluído com sucesso
     */
    @Override
    public boolean excluir(int id) {
        return itens.removeIf(item -> item.getProduto().getId() == id);
    }

    /**
     * Lista todos os itens presentes no carrinho.
     *
     * @return Representação textual dos itens e total
     */
    @Override
    public String listarTodos() {
        if (estaVazio()) {
            return "Carrinho vazio.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append(FormatadorTexto.criarCabecalho("Carrinho de Compras"));
        
        for (int i = 0; i < itens.size(); i++) {
            ItemPedido item = itens.get(i);
            sb.append(FormatadorTexto.formatarItemNumerado(i + 1, item.toString())).append("\n");
        }
        
        sb.append("\nValor Total: ").append(FormatadorTexto.formatarMoeda(calcularTotal()));
        return sb.toString();
    }

    /**
     * Calcula o valor total dos itens no carrinho.
     *
     * @return Valor total
     */
    public double calcularTotal() {
        double total = 0;
        for (ItemPedido item : itens) {
            total += item.calcularSubtotal();
        }
        return total;
    }

    /**
     * Verifica se o carrinho está vazio.
     *
     * @return true se o carrinho não contém itens
     */
    public boolean estaVazio() {
        return itens.isEmpty();
    }

    /**
     * Retorna a lista de itens do carrinho.
     *
     * @return Lista de ItemPedido (cópia defensiva)
     */
    public List<ItemPedido> getItens() {
        return new ArrayList<>(itens); // Retorna uma cópia para evitar modificação externa
    }

    /**
     * Limpa todos os itens do carrinho.
     */
    public void limpar() {
        this.itens.clear();
    }
    
    /**
     * Retorna a quantidade de itens no carrinho.
     * 
     * @return Quantidade de itens
     */
    public int getQuantidadeItens() {
        return itens.size();
    }
    
    /**
     * Atualiza a quantidade de um item no carrinho.
     * 
     * @param id ID do produto
     * @param quantidade Nova quantidade
     * @return true se a quantidade foi atualizada com sucesso
     * @throws IllegalArgumentException se a quantidade for inválida
     */
    public boolean atualizarQuantidade(int id, int quantidade) {
        if (!Validador.quantidadeValida(quantidade)) {
            throw new IllegalArgumentException("Quantidade deve ser maior que zero");
        }
        
        ItemPedido item = buscar(id);
        if (item != null) {
            item.setQuantidade(quantidade);
            return true;
        }
        return false;
    }
}
