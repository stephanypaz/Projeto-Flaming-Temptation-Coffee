package repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.text.SimpleDateFormat;
import interfaces.CRUD;
import model.ItemPedido;
import model.Pedido;
import util.FormatadorTexto;
import util.Validador;

/**
 * Classe que representa o repositório de pedidos da cafeteria.
 * Responsável por armazenar, gerenciar e fornecer acesso aos pedidos realizados.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 */
public class PedidoRepository implements CRUD<Pedido> {
    /** Lista de pedidos armazenados no sistema */
    private List<Pedido> pedidos;
    /** Contador para geração de números de pedido únicos */
    private int contadorPedidos;

    /**
     * Construtor da classe PedidoRepository.
     * Inicializa a lista de pedidos e o contador.
     */
    public PedidoRepository() {
        this.pedidos = new ArrayList<>();
        this.contadorPedidos = 1;
    }

    /**
     * Adiciona um novo pedido ao sistema.
     * Atribui automaticamente um número de pedido único e a data/hora atual.
     *
     * @param pedido Pedido a ser adicionado
     * @return true se o pedido foi adicionado com sucesso
     * @throws IllegalArgumentException se o pedido for nulo ou não tiver itens
     */
    @Override
    public boolean criar(Pedido pedido) {
        if (!Validador.objetoExiste(pedido)) {
            throw new IllegalArgumentException("Pedido não pode ser nulo");
        }
        
        if (pedido.getItens().isEmpty()) {
            throw new IllegalArgumentException("Pedido deve conter pelo menos um item");
        }
        
        // Atribui número de pedido único
        pedido.setNumeroPedido(contadorPedidos++);
        
        // Define data e hora atual se não estiver definida
        if (Validador.textoVazio(pedido.getDataHora())) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            pedido.setDataHora(sdf.format(new Date()));
        }
        
        return pedidos.add(pedido);
    }

    /**
     * Busca um pedido pelo seu número.
     *
     * @param numeroPedido Número do pedido a ser buscado
     * @return Pedido encontrado ou null se não existir
     */
    @Override
    public Pedido buscar(int numeroPedido) {
        for (Pedido pedido : pedidos) {
            if (pedido.getNumeroPedido() == numeroPedido) {
                return pedido;
            }
        }
        return null;
    }

    /**
     * Atualiza um pedido existente.
     *
     * @param numeroPedido Número do pedido a ser atualizado
     * @param novoPedido Pedido com as novas informações
     * @return true se o pedido foi atualizado com sucesso
     * @throws IllegalArgumentException se o novo pedido for nulo
     */
    @Override
    public boolean atualizar(int numeroPedido, Pedido novoPedido) {
        if (!Validador.objetoExiste(novoPedido)) {
            throw new IllegalArgumentException("Novo pedido não pode ser nulo");
        }
        
        for (int i = 0; i < pedidos.size(); i++) {
            if (pedidos.get(i).getNumeroPedido() == numeroPedido) {
                // Mantém o número do pedido original
                novoPedido.setNumeroPedido(numeroPedido);
                pedidos.set(i, novoPedido);
                return true;
            }
        }
        return false;
    }

    /**
     * Exclui um pedido pelo seu número.
     *
     * @param numeroPedido Número do pedido a ser excluído
     * @return true se o pedido foi excluído com sucesso
     */
    @Override
    public boolean excluir(int numeroPedido) {
        return pedidos.removeIf(pedido -> pedido.getNumeroPedido() == numeroPedido);
    }

    /**
     * Lista todos os pedidos armazenados.
     *
     * @return Representação textual de todos os pedidos
     */
    @Override
    public String listarTodos() {
        if (pedidos.isEmpty()) {
            return "Nenhum pedido registrado.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append(FormatadorTexto.criarCabecalho("Todos os Pedidos"));
        
        for (Pedido pedido : pedidos) {
            sb.append(String.format("Pedido #%d - %s - %s - %s\n", 
                pedido.getNumeroPedido(), 
                pedido.getNomeCliente(),
                FormatadorTexto.formatarMoeda(pedido.calcularTotal()),
                pedido.getStatus()));
        }
        
        return sb.toString();
    }

    /**
     * Retorna a lista de todos os pedidos.
     *
     * @return Lista de pedidos (cópia defensiva)
     */
    public List<Pedido> getPedidos() {
        return new ArrayList<>(pedidos);
    }
    
    /**
     * Retorna a quantidade de pedidos armazenados.
     *
     * @return Quantidade de pedidos
     */
    public int getQuantidadePedidos() {
        return pedidos.size();
    }
    
    /**
     * Atualiza o status de um pedido.
     *
     * @param numeroPedido Número do pedido
     * @param novoStatus Novo status do pedido
     * @return true se o status foi atualizado com sucesso
     * @throws IllegalArgumentException se o status for nulo ou vazio
     */
    public boolean atualizarStatus(int numeroPedido, String novoStatus) {
        if (Validador.textoVazio(novoStatus)) {
            throw new IllegalArgumentException("Status não pode ser nulo ou vazio");
        }
        
        Pedido pedido = buscar(numeroPedido);
        if (pedido != null) {
            pedido.setStatus(novoStatus);
            return true;
        }
        return false;
    }
    
    /**
     * Busca pedidos por nome do cliente.
     *
     * @param nomeCliente Nome do cliente para busca
     * @return Lista de pedidos do cliente
     * @throws IllegalArgumentException se o nome do cliente for nulo ou vazio
     */
    public List<Pedido> buscarPorCliente(String nomeCliente) {
        if (Validador.textoVazio(nomeCliente)) {
            throw new IllegalArgumentException("Nome do cliente não pode ser nulo ou vazio");
        }
        
        List<Pedido> pedidosCliente = new ArrayList<>();
        String nomeLowerCase = nomeCliente.toLowerCase();
        
        for (Pedido pedido : pedidos) {
            if (pedido.getNomeCliente().toLowerCase().contains(nomeLowerCase)) {
                pedidosCliente.add(pedido);
            }
        }
        
        return pedidosCliente;
    }
    
    /**
     * Busca pedidos por status.
     *
     * @param status Status para busca
     * @return Lista de pedidos com o status especificado
     * @throws IllegalArgumentException se o status for nulo ou vazio
     */
    public List<Pedido> buscarPorStatus(String status) {
        if (Validador.textoVazio(status)) {
            throw new IllegalArgumentException("Status não pode ser nulo ou vazio");
        }
        
        List<Pedido> pedidosStatus = new ArrayList<>();
        
        for (Pedido pedido : pedidos) {
            if (pedido.getStatus().equalsIgnoreCase(status)) {
                pedidosStatus.add(pedido);
            }
        }
        
        return pedidosStatus;
    }
}
