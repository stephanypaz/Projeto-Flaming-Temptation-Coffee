package test;

import java.util.ArrayList;
import java.util.List;
import model.Pedido;
import model.ItemPedido;
import model.Produto;
import model.Bebida;
import service.PedidoDatabaseService;
import service.ProdutoDatabaseService;
import config.DatabaseConfig;

/**
 * Classe de teste para validar a integração com banco de dados para pedidos.
 * Realiza testes de CRUD para garantir o funcionamento correto da persistência.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 * @since 1.1
 */
public class TestePedidoDatabase {
    
    /**
     * Método principal para execução dos testes.
     * 
     * @param args Argumentos de linha de comando (não utilizados)
     */
    public static void main(String[] args) {
        System.out.println("Iniciando testes de integração com banco de dados para pedidos...");
        
        // Inicializa os serviços
        PedidoDatabaseService servicePedido = new PedidoDatabaseService();
        ProdutoDatabaseService serviceProduto = new ProdutoDatabaseService();
        
        // Cria produtos para teste
        Bebida bebida = new Bebida(200, "Café Teste", "Café para teste de pedido", 5.50, "Bebidas Quentes", "Médio", true);
        serviceProduto.salvarProduto(bebida);
        
        // Teste de inserção de pedido
        System.out.println("\n=== Teste de Inserção de Pedido ===");
        
        // Cria itens para o pedido
        List<ItemPedido> itens = new ArrayList<>();
        itens.add(new ItemPedido(bebida, 2, "Sem açúcar"));
        
        // Cria o pedido
        Pedido pedido = new Pedido(1001, itens, "Cliente Teste", "Cartão de Crédito", "11/06/2025 20:30:00");
        pedido.setStatus("Novo");
        
        boolean inserido = servicePedido.salvarPedido(pedido);
        System.out.println("Pedido inserido: " + inserido);
        
        // Teste de busca por número
        System.out.println("\n=== Teste de Busca por Número ===");
        Pedido pedidoEncontrado = servicePedido.buscarPedidoPorNumero(1001);
        if (pedidoEncontrado != null) {
            System.out.println("Pedido encontrado: #" + pedidoEncontrado.getNumeroPedido());
            System.out.println("Cliente: " + pedidoEncontrado.getNomeCliente());
            System.out.println("Status: " + pedidoEncontrado.getStatus());
            System.out.println("Itens: " + pedidoEncontrado.getItens().size());
        } else {
            System.out.println("Pedido não encontrado!");
        }
        
        // Teste de listagem
        System.out.println("\n=== Teste de Listagem de Pedidos ===");
        List<Pedido> pedidos = servicePedido.listarTodosPedidos();
        System.out.println("Total de pedidos: " + pedidos.size());
        for (Pedido p : pedidos) {
            System.out.println("- #" + p.getNumeroPedido() + ": " + p.getNomeCliente() + " (" + p.getStatus() + ")");
        }
        
        // Teste de atualização de status
        System.out.println("\n=== Teste de Atualização de Status ===");
        boolean statusAtualizado = servicePedido.atualizarStatusPedido(1001, "Em Preparo");
        System.out.println("Status atualizado: " + statusAtualizado);
        
        // Verifica se a atualização foi efetiva
        pedidoEncontrado = servicePedido.buscarPedidoPorNumero(1001);
        if (pedidoEncontrado != null) {
            System.out.println("Novo status: " + pedidoEncontrado.getStatus());
        }
        
        // Teste de busca por cliente
        System.out.println("\n=== Teste de Busca por Cliente ===");
        List<Pedido> pedidosCliente = servicePedido.buscarPedidosPorCliente("Cliente");
        System.out.println("Pedidos do cliente: " + pedidosCliente.size());
        
        // Teste de busca por status
        System.out.println("\n=== Teste de Busca por Status ===");
        List<Pedido> pedidosStatus = servicePedido.buscarPedidosPorStatus("Em Preparo");
        System.out.println("Pedidos em preparo: " + pedidosStatus.size());
        
        // Teste de exclusão
        System.out.println("\n=== Teste de Exclusão ===");
        boolean excluido = servicePedido.excluirPedido(1001);
        System.out.println("Pedido excluído: " + excluido);
        
        // Verifica se a exclusão foi efetiva
        pedidoEncontrado = servicePedido.buscarPedidoPorNumero(1001);
        System.out.println("Pedido ainda existe: " + (pedidoEncontrado != null));
        
        // Limpa os produtos de teste
        serviceProduto.excluirProduto(200);
        
        // Fecha a conexão com o banco de dados
        DatabaseConfig.getInstance().closeConnection();
        
        System.out.println("\nTestes concluídos!");
    }
}
