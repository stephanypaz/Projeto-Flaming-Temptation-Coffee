package test;

import java.util.List;
import model.Produto;
import model.Bebida;
import model.Alimento;
import service.ProdutoDatabaseService;
import config.DatabaseConfig;

/**
 * Classe de teste para validar a integração com banco de dados para produtos.
 * Realiza testes de CRUD para garantir o funcionamento correto da persistência.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 * @since 1.1
 */
public class TesteProdutoDatabase {
    
    /**
     * Método principal para execução dos testes.
     * 
     * @param args Argumentos de linha de comando (não utilizados)
     */
    public static void main(String[] args) {
        System.out.println("Iniciando testes de integração com banco de dados para produtos...");
        
        // Inicializa o serviço
        ProdutoDatabaseService service = new ProdutoDatabaseService();
        
        // Teste de inserção
        System.out.println("\n=== Teste de Inserção ===");
        Bebida bebida = new Bebida(100, "Café Teste", "Café para teste de integração", 5.50, "Bebidas Quentes", "Médio", true);
        boolean inserido = service.salvarProduto(bebida);
        System.out.println("Produto inserido: " + inserido);
        
        Alimento alimento = new Alimento(101, "Bolo Teste", "Bolo para teste de integração", 8.00, "Alimentos", true, false);
        inserido = service.salvarProduto(alimento);
        System.out.println("Produto inserido: " + inserido);
        
        // Teste de busca por ID
        System.out.println("\n=== Teste de Busca por ID ===");
        Produto produtoEncontrado = service.buscarProdutoPorId(100);
        if (produtoEncontrado != null) {
            System.out.println("Produto encontrado: " + produtoEncontrado.getNome());
        } else {
            System.out.println("Produto não encontrado!");
        }
        
        // Teste de listagem
        System.out.println("\n=== Teste de Listagem ===");
        List<Produto> produtos = service.listarTodosProdutos();
        System.out.println("Total de produtos: " + produtos.size());
        for (Produto p : produtos) {
            System.out.println("- " + p.getId() + ": " + p.getNome() + " (" + p.getCategoria() + ")");
        }
        
        // Teste de atualização
        System.out.println("\n=== Teste de Atualização ===");
        if (produtoEncontrado != null) {
            produtoEncontrado.setPreco(6.50);
            boolean atualizado = service.atualizarProduto(produtoEncontrado);
            System.out.println("Produto atualizado: " + atualizado);
            
            // Verifica se a atualização foi efetiva
            Produto produtoAtualizado = service.buscarProdutoPorId(100);
            if (produtoAtualizado != null) {
                System.out.println("Preço atualizado: " + produtoAtualizado.getPreco());
            }
        }
        
        // Teste de busca por categoria
        System.out.println("\n=== Teste de Busca por Categoria ===");
        List<Produto> produtosCategoria = service.buscarProdutosPorCategoria("Alimentos");
        System.out.println("Produtos na categoria 'Alimentos': " + produtosCategoria.size());
        for (Produto p : produtosCategoria) {
            System.out.println("- " + p.getNome());
        }
        
        // Teste de exclusão
        System.out.println("\n=== Teste de Exclusão ===");
        boolean excluido = service.excluirProduto(101);
        System.out.println("Produto excluído: " + excluido);
        
        // Verifica se a exclusão foi efetiva
        Produto produtoExcluido = service.buscarProdutoPorId(101);
        System.out.println("Produto ainda existe: " + (produtoExcluido != null));
        
        // Fecha a conexão com o banco de dados
        DatabaseConfig.getInstance().closeConnection();
        
        System.out.println("\nTestes concluídos!");
    }
}
