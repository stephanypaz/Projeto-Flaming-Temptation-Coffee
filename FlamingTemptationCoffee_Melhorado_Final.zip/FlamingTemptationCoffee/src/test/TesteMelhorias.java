package test;

import model.Produto;
import model.Bebida;
import model.Alimento;
import model.ItemPedido;
import model.Pedido;
import service.ProdutoService;
import service.PedidoService;
import service.EstatisticaService;
import util.FormatadorTexto;
import util.Validador;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

/**
 * Classe de teste para validar as melhorias implementadas no projeto.
 * Realiza testes das classes utilitárias, serviços e uso de collections.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 * @since 1.1
 */
public class TesteMelhorias {
    
    /**
     * Método principal para execução dos testes.
     * 
     * @param args Argumentos de linha de comando (não utilizados)
     */
    public static void main(String[] args) {
        System.out.println("Iniciando testes das melhorias implementadas...");
        
        // Teste das classes utilitárias
        testarClassesUtilitarias();
        
        // Teste de collections
        testarCollections();
        
        // Teste de serviços
        testarServicos();
        
        System.out.println("\nTodos os testes concluídos com sucesso!");
    }
    
    /**
     * Testa as classes utilitárias implementadas.
     */
    private static void testarClassesUtilitarias() {
        System.out.println("\n=== Teste de Classes Utilitárias ===");
        
        // Teste de FormatadorTexto
        System.out.println("Testando FormatadorTexto...");
        String cabecalho = FormatadorTexto.criarCabecalho("Teste");
        System.out.println(cabecalho);
        
        String subcabecalho = FormatadorTexto.criarSubcabecalho("Subteste");
        System.out.println(subcabecalho);
        
        String itemNumerado = FormatadorTexto.formatarItemNumerado(1, "Item de teste");
        System.out.println(itemNumerado);
        
        String moeda = FormatadorTexto.formatarMoeda(15.75);
        System.out.println("Valor formatado: " + moeda);
        
        // Teste de Validador
        System.out.println("\nTestando Validador...");
        System.out.println("Texto vazio: " + Validador.textoVazio(""));
        System.out.println("Texto não vazio: " + Validador.textoVazio("Texto"));
        System.out.println("Valor positivo: " + Validador.valorPositivo(10.5));
        System.out.println("Valor não positivo: " + Validador.valorPositivo(-5.0));
        System.out.println("Quantidade válida: " + Validador.quantidadeValida(3));
        System.out.println("Quantidade inválida: " + Validador.quantidadeValida(0));
        System.out.println("ID válido: " + Validador.idValido(1));
        System.out.println("ID inválido: " + Validador.idValido(0));
        System.out.println("Objeto existe: " + Validador.objetoExiste(new Object()));
        System.out.println("Objeto não existe: " + Validador.objetoExiste(null));
    }
    
    /**
     * Testa o uso de collections nas classes do projeto.
     */
    private static void testarCollections() {
        System.out.println("\n=== Teste de Collections ===");
        
        // Teste de List em Produto (tags)
        System.out.println("Testando List em Produto (tags)...");
        Bebida bebida = new Bebida(1, "Café Expresso", "Café forte e encorpado", 5.00, "Bebidas Quentes", "Pequeno", true);
        bebida.adicionarTag("Especial");
        bebida.adicionarTag("Orgânico");
        
        List<String> tags = bebida.getTags();
        System.out.println("Tags: " + tags);
        
        // Teste de List em Bebida (ingredientes)
        System.out.println("\nTestando List em Bebida (ingredientes)...");
        bebida.adicionarIngrediente("Café");
        bebida.adicionarIngrediente("Água");
        
        List<String> ingredientes = bebida.getIngredientes();
        System.out.println("Ingredientes: " + ingredientes);
        
        // Teste de List em Alimento (alérgenos)
        System.out.println("\nTestando List em Alimento (alérgenos)...");
        Alimento alimento = new Alimento(2, "Bolo de Chocolate", "Bolo fofo de chocolate", 7.50, "Alimentos", false, false);
        alimento.adicionarAlergeno("Glúten");
        alimento.adicionarAlergeno("Leite");
        
        List<String> alergenos = alimento.getAlergenos();
        System.out.println("Alérgenos: " + alergenos);
        
        // Teste de List em ItemPedido (personalizações)
        System.out.println("\nTestando List em ItemPedido (personalizações)...");
        ItemPedido item = new ItemPedido(bebida, 2, "Sem açúcar");
        item.adicionarPersonalizacao("Extra quente");
        item.adicionarPersonalizacao("Com canela");
        
        List<String> personalizacoes = item.getPersonalizacoes();
        System.out.println("Personalizações: " + personalizacoes);
        
        // Teste de List e Map em Pedido
        System.out.println("\nTestando List e Map em Pedido...");
        List<ItemPedido> itens = new ArrayList<>();
        itens.add(item);
        itens.add(new ItemPedido(alimento, 1, ""));
        
        Pedido pedido = new Pedido(1, itens, "Cliente Teste", "Cartão de Crédito", "11/06/2025 20:30:00");
        pedido.adicionarObservacao("Entregar o mais rápido possível");
        pedido.adicionarDadoPagamento("numero_cartao", "****1234");
        pedido.adicionarDadoPagamento("validade", "12/27");
        
        System.out.println("Observações: " + pedido.getObservacoes());
        System.out.println("Dados de pagamento: " + pedido.getDadosPagamento());
    }
    
    /**
     * Testa os serviços implementados no projeto.
     */
    private static void testarServicos() {
        System.out.println("\n=== Teste de Serviços ===");
        
        // Cria uma lista de produtos para teste
        List<Produto> produtos = new ArrayList<>();
        produtos.add(new Bebida(1, "Café Expresso", "Café forte e encorpado", 5.00, "Bebidas Quentes", "Pequeno", true));
        produtos.add(new Bebida(2, "Cappuccino", "Espresso com leite vaporizado e espuma", 8.00, "Bebidas Quentes", "Médio", true));
        produtos.add(new Bebida(3, "Iced Coffee", "Café gelado refrescante", 7.00, "Bebidas Geladas", "Grande", false));
        produtos.add(new Alimento(4, "Croissant", "Massa folhada amanteigada", 6.00, "Alimentos", false, false));
        produtos.add(new Alimento(5, "Pão de Queijo", "Tradicional pão de queijo mineiro", 4.00, "Alimentos", true, false));
        
        // Teste de ProdutoService
        System.out.println("\nTestando ProdutoService...");
        
        List<Produto> bebidasQuentes = ProdutoService.filtrarPorCategoria(produtos, "Bebidas Quentes");
        System.out.println("Bebidas Quentes: " + bebidasQuentes.size());
        
        List<Produto> produtosBaratos = ProdutoService.filtrarPorFaixaDePreco(produtos, 0, 5.00);
        System.out.println("Produtos até R$ 5,00: " + produtosBaratos.size());
        
        List<Produto> resultadosBusca = ProdutoService.buscarPorNomeOuDescricao(produtos, "café");
        System.out.println("Produtos com 'café': " + resultadosBusca.size());
        
        List<String> categorias = ProdutoService.extrairCategorias(produtos);
        System.out.println("Categorias: " + categorias);
        
        // Teste de EstatisticaService
        System.out.println("\nTestando EstatisticaService...");
        
        Map<String, Double> precoMedio = EstatisticaService.calcularPrecoMedioPorCategoria(produtos);
        System.out.println("Preço médio por categoria: " + precoMedio);
        
        Map<String, Produto> maisCaros = EstatisticaService.encontrarProdutoMaisCaroPorCategoria(produtos);
        System.out.println("Produtos mais caros por categoria: ");
        for (Map.Entry<String, Produto> entry : maisCaros.entrySet()) {
            System.out.println("- " + entry.getKey() + ": " + entry.getValue().getNome() + " (" + entry.getValue().getPreco() + ")");
        }
        
        Map<String, Integer> contagem = EstatisticaService.contarProdutosPorCategoria(produtos);
        System.out.println("Contagem por categoria: " + contagem);
        
        // Teste de PedidoService
        System.out.println("\nTestando PedidoService...");
        
        List<ItemPedido> itensPedido = new ArrayList<>();
        itensPedido.add(new ItemPedido(produtos.get(0), 2, ""));
        itensPedido.add(new ItemPedido(produtos.get(3), 1, ""));
        
        double valorTotal = PedidoService.calcularValorTotal(itensPedido);
        System.out.println("Valor total do pedido: " + valorTotal);
        
        double totalDescontos = PedidoService.calcularTotalDescontos(itensPedido);
        System.out.println("Total de descontos: " + totalDescontos);
        
        boolean pedidoValido = PedidoService.pedidoValido(itensPedido);
        System.out.println("Pedido válido: " + pedidoValido);
        
        String resumo = PedidoService.gerarResumoPedido(itensPedido, 1);
        System.out.println("\nResumo do pedido:\n" + resumo);
        
        List<List<ItemPedido>> itensPorCategoria = PedidoService.agruparItensPorCategoria(itensPedido);
        System.out.println("Grupos de itens por categoria: " + itensPorCategoria.size());
    }
}
