package interfaces;

import model.Produto;
import java.util.List;

/**
 * Interface para gerenciamento de produtos no sistema.
 * Define operações específicas para manipulação de produtos.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 */
public interface GerenciamentoProdutos {
    
    /**
     * Adiciona um novo produto ao sistema.
     * 
     * @param produto Produto a ser adicionado
     * @return true se o produto foi adicionado com sucesso
     */
    boolean adicionarProduto(Produto produto);
    
    /**
     * Remove um produto do sistema pelo seu ID.
     * 
     * @param id ID do produto a ser removido
     * @return true se o produto foi removido com sucesso
     */
    boolean removerProduto(int id);
    
    /**
     * Busca produtos por categoria.
     * 
     * @param categoria Categoria desejada
     * @return Lista de produtos da categoria especificada
     */
    List<Produto> buscarPorCategoria(String categoria);
    
    /**
     * Busca produtos por faixa de preço.
     * 
     * @param precoMinimo Preço mínimo (inclusive)
     * @param precoMaximo Preço máximo (inclusive)
     * @return Lista de produtos dentro da faixa de preço
     */
    List<Produto> buscarPorFaixaDePreco(double precoMinimo, double precoMaximo);
    
    /**
     * Atualiza as informações de um produto existente.
     * 
     * @param id ID do produto a ser atualizado
     * @param produto Produto com as novas informações
     * @return true se o produto foi atualizado com sucesso
     */
    boolean atualizarProduto(int id, Produto produto);
}
