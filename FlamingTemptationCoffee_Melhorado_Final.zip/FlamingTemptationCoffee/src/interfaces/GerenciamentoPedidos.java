package interfaces;

import model.Pedido;
import java.util.List;

/**
 * Interface para gerenciamento de pedidos no sistema.
 * Define operações específicas para manipulação de pedidos.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 */
public interface GerenciamentoPedidos {
    
    /**
     * Registra um novo pedido no sistema.
     * 
     * @param pedido Pedido a ser registrado
     * @return true se o pedido foi registrado com sucesso
     */
    boolean registrarPedido(Pedido pedido);
    
    /**
     * Cancela um pedido existente.
     * 
     * @param numeroPedido Número do pedido a ser cancelado
     * @return true se o pedido foi cancelado com sucesso
     */
    boolean cancelarPedido(int numeroPedido);
    
    /**
     * Atualiza o status de um pedido.
     * 
     * @param numeroPedido Número do pedido
     * @param novoStatus Novo status do pedido
     * @return true se o status foi atualizado com sucesso
     */
    boolean atualizarStatusPedido(int numeroPedido, String novoStatus);
    
    /**
     * Busca pedidos por cliente.
     * 
     * @param nomeCliente Nome do cliente
     * @return Lista de pedidos do cliente especificado
     */
    List<Pedido> buscarPedidosPorCliente(String nomeCliente);
    
    /**
     * Busca pedidos por status.
     * 
     * @param status Status desejado
     * @return Lista de pedidos com o status especificado
     */
    List<Pedido> buscarPedidosPorStatus(String status);
}
