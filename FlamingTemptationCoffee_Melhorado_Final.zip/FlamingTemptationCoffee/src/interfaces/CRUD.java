package interfaces;

/**
 * Interface genérica para operações CRUD (Create, Read, Update, Delete).
 * Define os métodos básicos para manipulação de entidades no sistema.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 * @param <T> Tipo de entidade a ser manipulada
 */
public interface CRUD<T> {
    
    /**
     * Cria uma nova entidade no sistema.
     * 
     * @param entidade Entidade a ser criada
     * @return true se a entidade foi criada com sucesso
     */
    boolean criar(T entidade);
    
    /**
     * Busca uma entidade pelo seu identificador.
     * 
     * @param id Identificador da entidade
     * @return Entidade encontrada ou null se não existir
     */
    T buscar(int id);
    
    /**
     * Atualiza uma entidade existente.
     * 
     * @param id Identificador da entidade a ser atualizada
     * @param entidade Entidade com as novas informações
     * @return true se a entidade foi atualizada com sucesso
     */
    boolean atualizar(int id, T entidade);
    
    /**
     * Exclui uma entidade pelo seu identificador.
     * 
     * @param id Identificador da entidade a ser excluída
     * @return true se a entidade foi excluída com sucesso
     */
    boolean excluir(int id);
    
    /**
     * Lista todas as entidades disponíveis.
     * 
     * @return Representação textual de todas as entidades
     */
    String listarTodos();
}
