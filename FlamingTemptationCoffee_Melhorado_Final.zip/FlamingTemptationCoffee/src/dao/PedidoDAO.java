package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import config.DatabaseConfig;
import model.Pedido;
import model.ItemPedido;
import model.Produto;

/**
 * Classe DAO (Data Access Object) para operações de persistência de pedidos.
 * Responsável por realizar operações CRUD no banco de dados para pedidos.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 * @since 1.1
 */
public class PedidoDAO {
    
    private ProdutoDAO produtoDAO;
    
    /**
     * Construtor da classe PedidoDAO.
     * Inicializa o DAO de produtos necessário para operações relacionadas.
     */
    public PedidoDAO() {
        this.produtoDAO = new ProdutoDAO();
    }
    
    /**
     * Insere um pedido no banco de dados.
     * 
     * @param pedido Pedido a ser inserido
     * @return true se o pedido foi inserido com sucesso
     */
    public boolean inserir(Pedido pedido) {
        String sql = "INSERT INTO pedidos (numero_pedido, nome_cliente, status, forma_pagamento, data_hora) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, pedido.getNumeroPedido());
            stmt.setString(2, pedido.getNomeCliente());
            stmt.setString(3, pedido.getStatus());
            stmt.setString(4, pedido.getFormaPagamento());
            stmt.setString(5, pedido.getDataHora());
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                // Insere os itens do pedido
                return inserirItensPedido(pedido.getNumeroPedido(), pedido.getItens());
            }
            
            return false;
            
        } catch (SQLException e) {
            System.err.println("Erro ao inserir pedido: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Insere os itens de um pedido no banco de dados.
     * 
     * @param numeroPedido Número do pedido
     * @param itens Lista de itens do pedido
     * @return true se todos os itens foram inseridos com sucesso
     */
    private boolean inserirItensPedido(int numeroPedido, List<ItemPedido> itens) {
        String sql = "INSERT INTO itens_pedido (numero_pedido, produto_id, quantidade, observacoes) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            for (ItemPedido item : itens) {
                stmt.setInt(1, numeroPedido);
                stmt.setInt(2, item.getProduto().getId());
                stmt.setInt(3, item.getQuantidade());
                stmt.setString(4, item.getObservacoes());
                
                stmt.addBatch();
            }
            
            int[] resultados = stmt.executeBatch();
            
            // Verifica se todos os itens foram inseridos
            for (int resultado : resultados) {
                if (resultado <= 0) {
                    return false;
                }
            }
            
            return true;
            
        } catch (SQLException e) {
            System.err.println("Erro ao inserir itens do pedido: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Busca um pedido pelo seu número.
     * 
     * @param numeroPedido Número do pedido a ser buscado
     * @return Pedido encontrado ou null se não existir
     */
    public Pedido buscarPorNumero(int numeroPedido) {
        String sql = "SELECT * FROM pedidos WHERE numero_pedido = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, numeroPedido);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Pedido pedido = new Pedido();
                pedido.setNumeroPedido(rs.getInt("numero_pedido"));
                pedido.setNomeCliente(rs.getString("nome_cliente"));
                pedido.setStatus(rs.getString("status"));
                pedido.setFormaPagamento(rs.getString("forma_pagamento"));
                pedido.setDataHora(rs.getString("data_hora"));
                
                // Busca os itens do pedido
                List<ItemPedido> itens = buscarItensPedido(numeroPedido);
                pedido.setItens(itens);
                
                return pedido;
            }
            
            return null;
            
        } catch (SQLException e) {
            System.err.println("Erro ao buscar pedido por número: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Busca os itens de um pedido.
     * 
     * @param numeroPedido Número do pedido
     * @return Lista de itens do pedido
     */
    private List<ItemPedido> buscarItensPedido(int numeroPedido) {
        List<ItemPedido> itens = new ArrayList<>();
        String sql = "SELECT * FROM itens_pedido WHERE numero_pedido = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, numeroPedido);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                int produtoId = rs.getInt("produto_id");
                int quantidade = rs.getInt("quantidade");
                String observacoes = rs.getString("observacoes");
                
                // Busca o produto pelo ID
                Produto produto = produtoDAO.buscarPorId(produtoId);
                
                if (produto != null) {
                    ItemPedido item = new ItemPedido(produto, quantidade, observacoes);
                    itens.add(item);
                }
            }
            
            return itens;
            
        } catch (SQLException e) {
            System.err.println("Erro ao buscar itens do pedido: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Lista todos os pedidos do banco de dados.
     * 
     * @return Lista de pedidos
     */
    public List<Pedido> listarTodos() {
        List<Pedido> pedidos = new ArrayList<>();
        String sql = "SELECT * FROM pedidos";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                int numeroPedido = rs.getInt("numero_pedido");
                
                Pedido pedido = new Pedido();
                pedido.setNumeroPedido(numeroPedido);
                pedido.setNomeCliente(rs.getString("nome_cliente"));
                pedido.setStatus(rs.getString("status"));
                pedido.setFormaPagamento(rs.getString("forma_pagamento"));
                pedido.setDataHora(rs.getString("data_hora"));
                
                // Busca os itens do pedido
                List<ItemPedido> itens = buscarItensPedido(numeroPedido);
                pedido.setItens(itens);
                
                pedidos.add(pedido);
            }
            
            return pedidos;
            
        } catch (SQLException e) {
            System.err.println("Erro ao listar pedidos: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Atualiza um pedido no banco de dados.
     * 
     * @param pedido Pedido com as novas informações
     * @return true se o pedido foi atualizado com sucesso
     */
    public boolean atualizar(Pedido pedido) {
        String sql = "UPDATE pedidos SET nome_cliente = ?, status = ?, forma_pagamento = ?, data_hora = ? WHERE numero_pedido = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, pedido.getNomeCliente());
            stmt.setString(2, pedido.getStatus());
            stmt.setString(3, pedido.getFormaPagamento());
            stmt.setString(4, pedido.getDataHora());
            stmt.setInt(5, pedido.getNumeroPedido());
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                // Atualiza os itens do pedido (remove os antigos e insere os novos)
                excluirItensPedido(pedido.getNumeroPedido());
                return inserirItensPedido(pedido.getNumeroPedido(), pedido.getItens());
            }
            
            return false;
            
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar pedido: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Exclui os itens de um pedido.
     * 
     * @param numeroPedido Número do pedido
     * @return true se os itens foram excluídos com sucesso
     */
    private boolean excluirItensPedido(int numeroPedido) {
        String sql = "DELETE FROM itens_pedido WHERE numero_pedido = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, numeroPedido);
            int linhasAfetadas = stmt.executeUpdate();
            
            return linhasAfetadas >= 0; // Pode não ter itens para excluir
            
        } catch (SQLException e) {
            System.err.println("Erro ao excluir itens do pedido: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Exclui um pedido do banco de dados.
     * 
     * @param numeroPedido Número do pedido a ser excluído
     * @return true se o pedido foi excluído com sucesso
     */
    public boolean excluir(int numeroPedido) {
        // Primeiro exclui os itens do pedido
        if (excluirItensPedido(numeroPedido)) {
            // Depois exclui o pedido
            String sql = "DELETE FROM pedidos WHERE numero_pedido = ?";
            
            try (Connection conn = DatabaseConfig.getInstance().getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                
                stmt.setInt(1, numeroPedido);
                int linhasAfetadas = stmt.executeUpdate();
                
                return linhasAfetadas > 0;
                
            } catch (SQLException e) {
                System.err.println("Erro ao excluir pedido: " + e.getMessage());
                return false;
            }
        }
        
        return false;
    }
    
    /**
     * Busca pedidos por cliente.
     * 
     * @param nomeCliente Nome do cliente
     * @return Lista de pedidos do cliente
     */
    public List<Pedido> buscarPorCliente(String nomeCliente) {
        List<Pedido> pedidos = new ArrayList<>();
        String sql = "SELECT * FROM pedidos WHERE nome_cliente LIKE ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, "%" + nomeCliente + "%");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                int numeroPedido = rs.getInt("numero_pedido");
                
                Pedido pedido = new Pedido();
                pedido.setNumeroPedido(numeroPedido);
                pedido.setNomeCliente(rs.getString("nome_cliente"));
                pedido.setStatus(rs.getString("status"));
                pedido.setFormaPagamento(rs.getString("forma_pagamento"));
                pedido.setDataHora(rs.getString("data_hora"));
                
                // Busca os itens do pedido
                List<ItemPedido> itens = buscarItensPedido(numeroPedido);
                pedido.setItens(itens);
                
                pedidos.add(pedido);
            }
            
            return pedidos;
            
        } catch (SQLException e) {
            System.err.println("Erro ao buscar pedidos por cliente: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Busca pedidos por status.
     * 
     * @param status Status desejado
     * @return Lista de pedidos com o status especificado
     */
    public List<Pedido> buscarPorStatus(String status) {
        List<Pedido> pedidos = new ArrayList<>();
        String sql = "SELECT * FROM pedidos WHERE status = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                int numeroPedido = rs.getInt("numero_pedido");
                
                Pedido pedido = new Pedido();
                pedido.setNumeroPedido(numeroPedido);
                pedido.setNomeCliente(rs.getString("nome_cliente"));
                pedido.setStatus(rs.getString("status"));
                pedido.setFormaPagamento(rs.getString("forma_pagamento"));
                pedido.setDataHora(rs.getString("data_hora"));
                
                // Busca os itens do pedido
                List<ItemPedido> itens = buscarItensPedido(numeroPedido);
                pedido.setItens(itens);
                
                pedidos.add(pedido);
            }
            
            return pedidos;
            
        } catch (SQLException e) {
            System.err.println("Erro ao buscar pedidos por status: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Atualiza o status de um pedido.
     * 
     * @param numeroPedido Número do pedido
     * @param novoStatus Novo status do pedido
     * @return true se o status foi atualizado com sucesso
     */
    public boolean atualizarStatus(int numeroPedido, String novoStatus) {
        String sql = "UPDATE pedidos SET status = ? WHERE numero_pedido = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, novoStatus);
            stmt.setInt(2, numeroPedido);
            
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar status do pedido: " + e.getMessage());
            return false;
        }
    }
}
