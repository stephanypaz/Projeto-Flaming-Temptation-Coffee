package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import config.DatabaseConfig;
import model.Produto;
import model.Bebida;
import model.Alimento;

/**
 * Classe DAO (Data Access Object) para operações de persistência de produtos.
 * Responsável por realizar operações CRUD no banco de dados para produtos.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 * @since 1.1
 */
public class ProdutoDAO {
    
    /**
     * Insere um produto no banco de dados.
     * 
     * @param produto Produto a ser inserido
     * @return true se o produto foi inserido com sucesso
     */
    public boolean inserir(Produto produto) {
        String sql = "INSERT INTO produtos (id, nome, descricao, preco, categoria, tipo) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, produto.getId());
            stmt.setString(2, produto.getNome());
            stmt.setString(3, produto.getDescricao());
            stmt.setDouble(4, produto.getPreco());
            stmt.setString(5, produto.getCategoria());
            
            // Determina o tipo de produto
            String tipo = "Produto";
            if (produto instanceof Bebida) {
                tipo = "Bebida";
            } else if (produto instanceof Alimento) {
                tipo = "Alimento";
            }
            stmt.setString(6, tipo);
            
            int linhasAfetadas = stmt.executeUpdate();
            
            // Se for um tipo específico, insere na tabela correspondente
            if (produto instanceof Bebida) {
                inserirBebida((Bebida) produto);
            } else if (produto instanceof Alimento) {
                inserirAlimento((Alimento) produto);
            }
            
            return linhasAfetadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Erro ao inserir produto: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Insere uma bebida no banco de dados.
     * 
     * @param bebida Bebida a ser inserida
     * @return true se a bebida foi inserida com sucesso
     */
    private boolean inserirBebida(Bebida bebida) {
        String sql = "INSERT INTO bebidas (id, tamanho, quente) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, bebida.getId());
            stmt.setString(2, bebida.getTamanho());
            stmt.setBoolean(3, bebida.isQuente());
            
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Erro ao inserir bebida: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Insere um alimento no banco de dados.
     * 
     * @param alimento Alimento a ser inserido
     * @return true se o alimento foi inserido com sucesso
     */
    private boolean inserirAlimento(Alimento alimento) {
        String sql = "INSERT INTO alimentos (id, vegetariano, sem_gluten) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, alimento.getId());
            stmt.setBoolean(2, alimento.isVegetariano());
            stmt.setBoolean(3, alimento.isSemGluten());
            
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Erro ao inserir alimento: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Busca um produto pelo seu ID.
     * 
     * @param id ID do produto a ser buscado
     * @return Produto encontrado ou null se não existir
     */
    public Produto buscarPorId(int id) {
        String sql = "SELECT p.*, b.tamanho, b.quente, a.vegetariano, a.sem_gluten " +
                     "FROM produtos p " +
                     "LEFT JOIN bebidas b ON p.id = b.id " +
                     "LEFT JOIN alimentos a ON p.id = a.id " +
                     "WHERE p.id = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                String tipo = rs.getString("tipo");
                
                if ("Bebida".equals(tipo)) {
                    return new Bebida(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("descricao"),
                        rs.getDouble("preco"),
                        rs.getString("categoria"),
                        rs.getString("tamanho"),
                        rs.getBoolean("quente")
                    );
                } else if ("Alimento".equals(tipo)) {
                    return new Alimento(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("descricao"),
                        rs.getDouble("preco"),
                        rs.getString("categoria"),
                        rs.getBoolean("vegetariano"),
                        rs.getBoolean("sem_gluten")
                    );
                }
            }
            
            return null;
            
        } catch (SQLException e) {
            System.err.println("Erro ao buscar produto por ID: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Lista todos os produtos do banco de dados.
     * 
     * @return Lista de produtos
     */
    public List<Produto> listarTodos() {
        List<Produto> produtos = new ArrayList<>();
        String sql = "SELECT p.*, b.tamanho, b.quente, a.vegetariano, a.sem_gluten " +
                     "FROM produtos p " +
                     "LEFT JOIN bebidas b ON p.id = b.id " +
                     "LEFT JOIN alimentos a ON p.id = a.id";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                String tipo = rs.getString("tipo");
                
                if ("Bebida".equals(tipo)) {
                    produtos.add(new Bebida(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("descricao"),
                        rs.getDouble("preco"),
                        rs.getString("categoria"),
                        rs.getString("tamanho"),
                        rs.getBoolean("quente")
                    ));
                } else if ("Alimento".equals(tipo)) {
                    produtos.add(new Alimento(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("descricao"),
                        rs.getDouble("preco"),
                        rs.getString("categoria"),
                        rs.getBoolean("vegetariano"),
                        rs.getBoolean("sem_gluten")
                    ));
                }
            }
            
            return produtos;
            
        } catch (SQLException e) {
            System.err.println("Erro ao listar produtos: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Atualiza um produto no banco de dados.
     * 
     * @param produto Produto com as novas informações
     * @return true se o produto foi atualizado com sucesso
     */
    public boolean atualizar(Produto produto) {
        String sql = "UPDATE produtos SET nome = ?, descricao = ?, preco = ?, categoria = ? WHERE id = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, produto.getNome());
            stmt.setString(2, produto.getDescricao());
            stmt.setDouble(3, produto.getPreco());
            stmt.setString(4, produto.getCategoria());
            stmt.setInt(5, produto.getId());
            
            int linhasAfetadas = stmt.executeUpdate();
            
            // Atualiza tabelas específicas se necessário
            if (produto instanceof Bebida) {
                atualizarBebida((Bebida) produto);
            } else if (produto instanceof Alimento) {
                atualizarAlimento((Alimento) produto);
            }
            
            return linhasAfetadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar produto: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Atualiza uma bebida no banco de dados.
     * 
     * @param bebida Bebida com as novas informações
     * @return true se a bebida foi atualizada com sucesso
     */
    private boolean atualizarBebida(Bebida bebida) {
        String sql = "UPDATE bebidas SET tamanho = ?, quente = ? WHERE id = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, bebida.getTamanho());
            stmt.setBoolean(2, bebida.isQuente());
            stmt.setInt(3, bebida.getId());
            
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar bebida: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Atualiza um alimento no banco de dados.
     * 
     * @param alimento Alimento com as novas informações
     * @return true se o alimento foi atualizado com sucesso
     */
    private boolean atualizarAlimento(Alimento alimento) {
        String sql = "UPDATE alimentos SET vegetariano = ?, sem_gluten = ? WHERE id = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setBoolean(1, alimento.isVegetariano());
            stmt.setBoolean(2, alimento.isSemGluten());
            stmt.setInt(3, alimento.getId());
            
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar alimento: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Exclui um produto do banco de dados.
     * 
     * @param id ID do produto a ser excluído
     * @return true se o produto foi excluído com sucesso
     */
    public boolean excluir(int id) {
        // Primeiro verifica o tipo do produto
        String sqlTipo = "SELECT tipo FROM produtos WHERE id = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmtTipo = conn.prepareStatement(sqlTipo)) {
            
            stmtTipo.setInt(1, id);
            ResultSet rs = stmtTipo.executeQuery();
            
            if (rs.next()) {
                String tipo = rs.getString("tipo");
                
                // Exclui da tabela específica primeiro
                if ("Bebida".equals(tipo)) {
                    excluirBebida(id);
                } else if ("Alimento".equals(tipo)) {
                    excluirAlimento(id);
                }
                
                // Depois exclui da tabela principal
                String sqlProduto = "DELETE FROM produtos WHERE id = ?";
                try (PreparedStatement stmtProduto = conn.prepareStatement(sqlProduto)) {
                    stmtProduto.setInt(1, id);
                    int linhasAfetadas = stmtProduto.executeUpdate();
                    return linhasAfetadas > 0;
                }
            }
            
            return false;
            
        } catch (SQLException e) {
            System.err.println("Erro ao excluir produto: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Exclui uma bebida do banco de dados.
     * 
     * @param id ID da bebida a ser excluída
     * @return true se a bebida foi excluída com sucesso
     */
    private boolean excluirBebida(int id) {
        String sql = "DELETE FROM bebidas WHERE id = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Erro ao excluir bebida: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Exclui um alimento do banco de dados.
     * 
     * @param id ID do alimento a ser excluído
     * @return true se o alimento foi excluído com sucesso
     */
    private boolean excluirAlimento(int id) {
        String sql = "DELETE FROM alimentos WHERE id = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Erro ao excluir alimento: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Busca produtos por categoria.
     * 
     * @param categoria Categoria desejada
     * @return Lista de produtos da categoria
     */
    public List<Produto> buscarPorCategoria(String categoria) {
        List<Produto> produtos = new ArrayList<>();
        String sql = "SELECT p.*, b.tamanho, b.quente, a.vegetariano, a.sem_gluten " +
                     "FROM produtos p " +
                     "LEFT JOIN bebidas b ON p.id = b.id " +
                     "LEFT JOIN alimentos a ON p.id = a.id " +
                     "WHERE p.categoria = ?";
        
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, categoria);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                String tipo = rs.getString("tipo");
                
                if ("Bebida".equals(tipo)) {
                    produtos.add(new Bebida(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("descricao"),
                        rs.getDouble("preco"),
                        rs.getString("categoria"),
                        rs.getString("tamanho"),
                        rs.getBoolean("quente")
                    ));
                } else if ("Alimento".equals(tipo)) {
                    produtos.add(new Alimento(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("descricao"),
                        rs.getDouble("preco"),
                        rs.getString("categoria"),
                        rs.getBoolean("vegetariano"),
                        rs.getBoolean("sem_gluten")
                    ));
                }
            }
            
            return produtos;
            
        } catch (SQLException e) {
            System.err.println("Erro ao buscar produtos por categoria: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
