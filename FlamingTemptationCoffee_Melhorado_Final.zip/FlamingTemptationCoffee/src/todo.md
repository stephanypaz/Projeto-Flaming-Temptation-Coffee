# Lista de Tarefas - Refatoração do Projeto Flaming Temptation Coffee

## Análise e Planejamento
- [x] Descompactar e analisar o arquivo ZIP
- [x] Identificar estrutura existente e classes principais
- [x] Planejar organização em pacotes model, view e interfaces
- [x] Criar estrutura de diretórios para os pacotes

## Implementação de Interfaces
- [x] Criar interface CRUD genérica
- [x] Criar interfaces específicas para gerenciamento de produtos
- [x] Criar interfaces para gerenciamento de pedidos

## Implementação do Pacote Model
- [x] Implementar classe abstrata base para produtos
- [x] Implementar subclasses de produtos (bebidas, comidas, etc.)
- [x] Implementar classe ItemPedido
- [x] Implementar classe Carrinho com implementação da interface CRUD
- [x] Implementar classe Pedido
- [x] Aplicar herança, polimorfismo e sobrescrita nas classes do model

## Implementação do Pacote View
- [x] Implementar classe principal de interface com usuário
- [x] Implementar classes de visualização para diferentes funcionalidades
- [x] Separar lógica de negócio da interface com usuário

## Documentação
- [x] Adicionar JavaDoc em todas as classes e métodos
- [x] Documentar uso de herança, polimorfismo, sobrecarga e sobrescrita
- [ ] Verificar se todos os requisitos foram atendidos

## Validação e Entrega
- [ ] Compilar e testar o código
- [ ] Verificar funcionalidade completa do sistema
- [ ] Entregar código refatorado ao usuário
