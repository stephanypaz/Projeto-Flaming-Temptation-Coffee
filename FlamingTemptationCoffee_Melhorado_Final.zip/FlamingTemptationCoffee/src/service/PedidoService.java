package service;

import java.util.ArrayList;
import java.util.List;
import model.Produto;
import model.ItemPedido;
import util.Validador;
import util.FormatadorTexto;

/**
 * Classe de serviço para gerenciamento de pedidos.
 * Responsável por operações relacionadas ao processamento de pedidos.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 */
public class PedidoService {
    
    /**
     * Calcula o valor total de um pedido com base nos itens.
     * 
     * @param itens Lista de itens do pedido
     * @return Valor total do pedido
     */
    public static double calcularValorTotal(List<ItemPedido> itens) {
        if (itens == null || itens.isEmpty()) {
            return 0.0;
        }
        
        double total = 0.0;
        for (ItemPedido item : itens) {
            total += item.calcularSubtotal();
        }
        
        return total;
    }
    
    /**
     * Calcula o valor total de desconto em um pedido.
     * 
     * @param itens Lista de itens do pedido
     * @return Valor total de desconto
     */
    public static double calcularTotalDescontos(List<ItemPedido> itens) {
        if (itens == null || itens.isEmpty()) {
            return 0.0;
        }
        
        double totalDescontos = 0.0;
        for (ItemPedido item : itens) {
            Produto produto = item.getProduto();
            double desconto = produto.calcularDesconto() * item.getQuantidade();
            totalDescontos += desconto;
        }
        
        return totalDescontos;
    }
    
    /**
     * Verifica se um pedido é válido para processamento.
     * 
     * @param itens Lista de itens do pedido
     * @return true se o pedido for válido
     */
    public static boolean pedidoValido(List<ItemPedido> itens) {
        return itens != null && !itens.isEmpty();
    }
    
    /**
     * Gera um resumo formatado do pedido.
     * 
     * @param itens Lista de itens do pedido
     * @param numeroPedido Número do pedido
     * @return String formatada com o resumo do pedido
     */
    public static String gerarResumoPedido(List<ItemPedido> itens, int numeroPedido) {
        if (!pedidoValido(itens)) {
            return "Pedido inválido.";
        }
        
        StringBuilder resumo = new StringBuilder();
        resumo.append(FormatadorTexto.criarCabecalho("Resumo do Pedido #" + numeroPedido));
        
        for (int i = 0; i < itens.size(); i++) {
            ItemPedido item = itens.get(i);
            resumo.append(FormatadorTexto.formatarItemNumerado(i + 1, item.toString())).append("\n");
        }
        
        double valorTotal = calcularValorTotal(itens);
        double descontos = calcularTotalDescontos(itens);
        double valorFinal = valorTotal - descontos;
        
        resumo.append("\nSubtotal: ").append(FormatadorTexto.formatarMoeda(valorTotal));
        
        if (descontos > 0) {
            resumo.append("\nDescontos: ").append(FormatadorTexto.formatarMoeda(descontos));
        }
        
        resumo.append("\nValor Final: ").append(FormatadorTexto.formatarMoeda(valorFinal));
        
        return resumo.toString();
    }
    
    /**
     * Agrupa itens do pedido por categoria.
     * 
     * @param itens Lista de itens do pedido
     * @return Lista de itens agrupados por categoria
     */
    public static List<List<ItemPedido>> agruparItensPorCategoria(List<ItemPedido> itens) {
        if (!pedidoValido(itens)) {
            return new ArrayList<>();
        }
        
        // Implementação simplificada - em um cenário real usaríamos Map<String, List<ItemPedido>>
        List<String> categorias = new ArrayList<>();
        List<List<ItemPedido>> itensPorCategoria = new ArrayList<>();
        
        for (ItemPedido item : itens) {
            String categoria = item.getProduto().getCategoria();
            
            int index = categorias.indexOf(categoria);
            if (index == -1) {
                categorias.add(categoria);
                List<ItemPedido> novaLista = new ArrayList<>();
                novaLista.add(item);
                itensPorCategoria.add(novaLista);
            } else {
                itensPorCategoria.get(index).add(item);
            }
        }
        
        return itensPorCategoria;
    }
}
