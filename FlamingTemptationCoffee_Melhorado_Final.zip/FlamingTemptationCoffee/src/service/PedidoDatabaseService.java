package service;

import java.util.List;
import dao.PedidoDAO;
import model.Pedido;

/**
 * Classe de serviço para integração com banco de dados para pedidos.
 * Responsável por intermediar a comunicação entre a camada de visualização e a camada de acesso a dados.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 * @since 1.1
 */
public class PedidoDatabaseService {
    
    /** DAO para acesso aos dados de pedidos */
    private PedidoDAO pedidoDAO;
    
    /**
     * Construtor da classe PedidoDatabaseService.
     * Inicializa o DAO de pedidos.
     */
    public PedidoDatabaseService() {
        this.pedidoDAO = new PedidoDAO();
    }
    
    /**
     * Salva um pedido no banco de dados.
     * 
     * @param pedido Pedido a ser salvo
     * @return true se o pedido foi salvo com sucesso
     */
    public boolean salvarPedido(Pedido pedido) {
        return pedidoDAO.inserir(pedido);
    }
    
    /**
     * Busca um pedido pelo seu número.
     * 
     * @param numeroPedido Número do pedido a ser buscado
     * @return Pedido encontrado ou null se não existir
     */
    public Pedido buscarPedidoPorNumero(int numeroPedido) {
        return pedidoDAO.buscarPorNumero(numeroPedido);
    }
    
    /**
     * Lista todos os pedidos do banco de dados.
     * 
     * @return Lista de pedidos
     */
    public List<Pedido> listarTodosPedidos() {
        return pedidoDAO.listarTodos();
    }
    
    /**
     * Atualiza um pedido no banco de dados.
     * 
     * @param pedido Pedido com as novas informações
     * @return true se o pedido foi atualizado com sucesso
     */
    public boolean atualizarPedido(Pedido pedido) {
        return pedidoDAO.atualizar(pedido);
    }
    
    /**
     * Exclui um pedido do banco de dados.
     * 
     * @param numeroPedido Número do pedido a ser excluído
     * @return true se o pedido foi excluído com sucesso
     */
    public boolean excluirPedido(int numeroPedido) {
        return pedidoDAO.excluir(numeroPedido);
    }
    
    /**
     * Busca pedidos por cliente.
     * 
     * @param nomeCliente Nome do cliente
     * @return Lista de pedidos do cliente
     */
    public List<Pedido> buscarPedidosPorCliente(String nomeCliente) {
        return pedidoDAO.buscarPorCliente(nomeCliente);
    }
    
    /**
     * Busca pedidos por status.
     * 
     * @param status Status desejado
     * @return Lista de pedidos com o status especificado
     */
    public List<Pedido> buscarPedidosPorStatus(String status) {
        return pedidoDAO.buscarPorStatus(status);
    }
    
    /**
     * Atualiza o status de um pedido.
     * 
     * @param numeroPedido Número do pedido
     * @param novoStatus Novo status do pedido
     * @return true se o status foi atualizado com sucesso
     */
    public boolean atualizarStatusPedido(int numeroPedido, String novoStatus) {
        return pedidoDAO.atualizarStatus(numeroPedido, novoStatus);
    }
    
    /**
     * Sincroniza os pedidos em memória com o banco de dados.
     * 
     * @param pedidos Lista de pedidos em memória
     * @return true se a sincronização foi bem-sucedida
     */
    public boolean sincronizarPedidos(List<Pedido> pedidos) {
        boolean sucesso = true;
        
        // Limpa o banco de dados (simplificação - em um cenário real, faria uma sincronização mais inteligente)
        List<Pedido> pedidosDB = pedidoDAO.listarTodos();
        for (Pedido pedido : pedidosDB) {
            if (!pedidoDAO.excluir(pedido.getNumeroPedido())) {
                sucesso = false;
            }
        }
        
        // Insere todos os pedidos da memória
        for (Pedido pedido : pedidos) {
            if (!pedidoDAO.inserir(pedido)) {
                sucesso = false;
            }
        }
        
        return sucesso;
    }
}
