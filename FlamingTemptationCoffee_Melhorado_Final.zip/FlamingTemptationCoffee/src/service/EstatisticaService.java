package service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.Produto;
import util.Validador;

/**
 * Classe de serviço para gerenciamento de estatísticas de produtos.
 * Responsável por calcular e fornecer estatísticas sobre os produtos do sistema.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 */
public class EstatisticaService {
    
    /**
     * Calcula o preço médio dos produtos por categoria.
     * 
     * @param produtos Lista de produtos para análise
     * @return Mapa com categorias e seus preços médios
     */
    public static Map<String, Double> calcularPrecoMedioPorCategoria(List<Produto> produtos) {
        if (produtos == null || produtos.isEmpty()) {
            return new HashMap<>();
        }
        
        Map<String, List<Double>> precosPorCategoria = new HashMap<>();
        Map<String, Double> precoMedioPorCategoria = new HashMap<>();
        
        // Agrupa os preços por categoria
        for (Produto produto : produtos) {
            String categoria = produto.getCategoria();
            double preco = produto.getPreco();
            
            if (!precosPorCategoria.containsKey(categoria)) {
                precosPorCategoria.put(categoria, new ArrayList<>());
            }
            
            precosPorCategoria.get(categoria).add(preco);
        }
        
        // Calcula a média para cada categoria
        for (Map.Entry<String, List<Double>> entry : precosPorCategoria.entrySet()) {
            String categoria = entry.getKey();
            List<Double> precos = entry.getValue();
            
            double soma = 0;
            for (Double preco : precos) {
                soma += preco;
            }
            
            double media = soma / precos.size();
            precoMedioPorCategoria.put(categoria, media);
        }
        
        return precoMedioPorCategoria;
    }
    
    /**
     * Encontra o produto mais caro em cada categoria.
     * 
     * @param produtos Lista de produtos para análise
     * @return Mapa com categorias e seus produtos mais caros
     */
    public static Map<String, Produto> encontrarProdutoMaisCaroPorCategoria(List<Produto> produtos) {
        if (produtos == null || produtos.isEmpty()) {
            return new HashMap<>();
        }
        
        Map<String, Produto> maisCaroPorCategoria = new HashMap<>();
        
        for (Produto produto : produtos) {
            String categoria = produto.getCategoria();
            
            if (!maisCaroPorCategoria.containsKey(categoria) || 
                produto.getPreco() > maisCaroPorCategoria.get(categoria).getPreco()) {
                maisCaroPorCategoria.put(categoria, produto);
            }
        }
        
        return maisCaroPorCategoria;
    }
    
    /**
     * Conta o número de produtos por categoria.
     * 
     * @param produtos Lista de produtos para análise
     * @return Mapa com categorias e suas contagens
     */
    public static Map<String, Integer> contarProdutosPorCategoria(List<Produto> produtos) {
        if (produtos == null || produtos.isEmpty()) {
            return new HashMap<>();
        }
        
        Map<String, Integer> contagemPorCategoria = new HashMap<>();
        
        for (Produto produto : produtos) {
            String categoria = produto.getCategoria();
            
            contagemPorCategoria.put(categoria, 
                contagemPorCategoria.getOrDefault(categoria, 0) + 1);
        }
        
        return contagemPorCategoria;
    }
    
    /**
     * Calcula o valor total do inventário por categoria.
     * 
     * @param produtos Lista de produtos para análise
     * @return Mapa com categorias e seus valores totais
     */
    public static Map<String, Double> calcularValorTotalPorCategoria(List<Produto> produtos) {
        if (produtos == null || produtos.isEmpty()) {
            return new HashMap<>();
        }
        
        Map<String, Double> valorTotalPorCategoria = new HashMap<>();
        
        for (Produto produto : produtos) {
            String categoria = produto.getCategoria();
            double preco = produto.getPreco();
            
            valorTotalPorCategoria.put(categoria, 
                valorTotalPorCategoria.getOrDefault(categoria, 0.0) + preco);
        }
        
        return valorTotalPorCategoria;
    }
}
