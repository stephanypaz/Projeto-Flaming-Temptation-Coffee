package service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import model.Produto;
import util.Validador;
import util.FormatadorTexto;

/**
 * Classe de serviço para gerenciamento de produtos.
 * Responsável por operações relacionadas ao processamento e filtragem de produtos.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 */
public class ProdutoService {
    
    /**
     * Filtra produtos por categoria.
     * 
     * @param produtos Lista de produtos para filtrar
     * @param categoria Categoria desejada
     * @return Lista de produtos da categoria especificada
     */
    public static List<Produto> filtrarPorCategoria(List<Produto> produtos, String categoria) {
        if (produtos == null || Validador.textoVazio(categoria)) {
            return new ArrayList<>();
        }
        
        List<Produto> produtosFiltrados = new ArrayList<>();
        for (Produto produto : produtos) {
            if (produto.getCategoria().equalsIgnoreCase(categoria)) {
                produtosFiltrados.add(produto);
            }
        }
        
        return produtosFiltrados;
    }
    
    /**
     * Filtra produtos por faixa de preço.
     * 
     * @param produtos Lista de produtos para filtrar
     * @param precoMinimo Preço mínimo (inclusive)
     * @param precoMaximo Preço máximo (inclusive)
     * @return Lista de produtos dentro da faixa de preço
     */
    public static List<Produto> filtrarPorFaixaDePreco(List<Produto> produtos, double precoMinimo, double precoMaximo) {
        if (produtos == null || precoMinimo > precoMaximo) {
            return new ArrayList<>();
        }
        
        List<Produto> produtosFiltrados = new ArrayList<>();
        for (Produto produto : produtos) {
            double preco = produto.getPreco();
            if (preco >= precoMinimo && preco <= precoMaximo) {
                produtosFiltrados.add(produto);
            }
        }
        
        return produtosFiltrados;
    }
    
    /**
     * Busca produtos por nome ou descrição.
     * 
     * @param produtos Lista de produtos para buscar
     * @param termoBusca Termo a ser buscado no nome ou descrição
     * @return Lista de produtos que contêm o termo buscado
     */
    public static List<Produto> buscarPorNomeOuDescricao(List<Produto> produtos, String termoBusca) {
        if (produtos == null || Validador.textoVazio(termoBusca)) {
            return new ArrayList<>();
        }
        
        String termoLowerCase = termoBusca.toLowerCase();
        List<Produto> produtosEncontrados = new ArrayList<>();
        
        for (Produto produto : produtos) {
            if (produto.getNome().toLowerCase().contains(termoLowerCase) || 
                produto.getDescricao().toLowerCase().contains(termoLowerCase)) {
                produtosEncontrados.add(produto);
            }
        }
        
        return produtosEncontrados;
    }
    
    /**
     * Extrai todas as categorias distintas de uma lista de produtos.
     * 
     * @param produtos Lista de produtos para extrair categorias
     * @return Lista de categorias distintas
     */
    public static List<String> extrairCategorias(List<Produto> produtos) {
        if (produtos == null || produtos.isEmpty()) {
            return new ArrayList<>();
        }
        
        List<String> categorias = new ArrayList<>();
        for (Produto produto : produtos) {
            String categoria = produto.getCategoria();
            if (!categorias.contains(categoria)) {
                categorias.add(categoria);
            }
        }
        
        return categorias;
    }
    
    /**
     * Formata uma lista de produtos para exibição.
     * 
     * @param produtos Lista de produtos para formatar
     * @return String formatada com os produtos
     */
    public static String formatarListaProdutos(List<Produto> produtos) {
        if (produtos == null || produtos.isEmpty()) {
            return "Nenhum produto encontrado.";
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append(FormatadorTexto.criarCabecalho("Lista de Produtos"));
        
        Map<String, List<Produto>> produtosPorCategoria = new HashMap<>();
        
        // Agrupar produtos por categoria
        for (Produto produto : produtos) {
            String categoria = produto.getCategoria();
            if (!produtosPorCategoria.containsKey(categoria)) {
                produtosPorCategoria.put(categoria, new ArrayList<>());
            }
            produtosPorCategoria.get(categoria).add(produto);
        }
        
        // Formatar por categoria
        for (Map.Entry<String, List<Produto>> entry : produtosPorCategoria.entrySet()) {
            String categoria = entry.getKey();
            List<Produto> produtosCategoria = entry.getValue();
            
            sb.append(FormatadorTexto.criarSubcabecalho(categoria));
            
            for (int i = 0; i < produtosCategoria.size(); i++) {
                Produto produto = produtosCategoria.get(i);
                sb.append(FormatadorTexto.formatarItemNumerado(i + 1, produto.getNome()))
                  .append(" - ")
                  .append(FormatadorTexto.formatarMoeda(produto.getPreco()))
                  .append("\n");
            }
        }
        
        return sb.toString();
    }
}
