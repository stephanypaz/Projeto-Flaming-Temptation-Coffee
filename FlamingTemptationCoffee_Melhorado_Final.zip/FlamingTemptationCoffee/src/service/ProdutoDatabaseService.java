package service;

import java.util.List;
import dao.ProdutoDAO;
import model.Produto;
import model.Bebida;
import model.Alimento;

/**
 * Classe de serviço para integração com banco de dados para produtos.
 * Responsável por intermediar a comunicação entre a camada de visualização e a camada de acesso a dados.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.0
 * @since 1.1
 */
public class ProdutoDatabaseService {
    
    /** DAO para acesso aos dados de produtos */
    private ProdutoDAO produtoDAO;
    
    /**
     * Construtor da classe ProdutoDatabaseService.
     * Inicializa o DAO de produtos.
     */
    public ProdutoDatabaseService() {
        this.produtoDAO = new ProdutoDAO();
    }
    
    /**
     * Salva um produto no banco de dados.
     * 
     * @param produto Produto a ser salvo
     * @return true se o produto foi salvo com sucesso
     */
    public boolean salvarProduto(Produto produto) {
        return produtoDAO.inserir(produto);
    }
    
    /**
     * Busca um produto pelo seu ID.
     * 
     * @param id ID do produto a ser buscado
     * @return Produto encontrado ou null se não existir
     */
    public Produto buscarProdutoPorId(int id) {
        return produtoDAO.buscarPorId(id);
    }
    
    /**
     * Lista todos os produtos do banco de dados.
     * 
     * @return Lista de produtos
     */
    public List<Produto> listarTodosProdutos() {
        return produtoDAO.listarTodos();
    }
    
    /**
     * Atualiza um produto no banco de dados.
     * 
     * @param produto Produto com as novas informações
     * @return true se o produto foi atualizado com sucesso
     */
    public boolean atualizarProduto(Produto produto) {
        return produtoDAO.atualizar(produto);
    }
    
    /**
     * Exclui um produto do banco de dados.
     * 
     * @param id ID do produto a ser excluído
     * @return true se o produto foi excluído com sucesso
     */
    public boolean excluirProduto(int id) {
        return produtoDAO.excluir(id);
    }
    
    /**
     * Busca produtos por categoria.
     * 
     * @param categoria Categoria desejada
     * @return Lista de produtos da categoria
     */
    public List<Produto> buscarProdutosPorCategoria(String categoria) {
        return produtoDAO.buscarPorCategoria(categoria);
    }
    
    /**
     * Sincroniza os produtos em memória com o banco de dados.
     * 
     * @param produtos Lista de produtos em memória
     * @return true se a sincronização foi bem-sucedida
     */
    public boolean sincronizarProdutos(List<Produto> produtos) {
        boolean sucesso = true;
        
        // Limpa o banco de dados (simplificação - em um cenário real, faria uma sincronização mais inteligente)
        List<Produto> produtosDB = produtoDAO.listarTodos();
        for (Produto produto : produtosDB) {
            if (!produtoDAO.excluir(produto.getId())) {
                sucesso = false;
            }
        }
        
        // Insere todos os produtos da memória
        for (Produto produto : produtos) {
            if (!produtoDAO.inserir(produto)) {
                sucesso = false;
            }
        }
        
        return sucesso;
    }
    
    /**
     * Carrega produtos do banco de dados para a memória.
     * 
     * @return Lista de produtos carregados do banco de dados
     */
    public List<Produto> carregarProdutosDoDatabase() {
        return produtoDAO.listarTodos();
    }
}
