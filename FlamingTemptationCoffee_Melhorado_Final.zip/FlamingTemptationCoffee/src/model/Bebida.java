package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa uma bebida no sistema, estendendo a classe abstrata Produto.
 * Armazena informações específicas de bebidas como tamanho e temperatura.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 */
public class Bebida extends Produto {
    /** Tamanho da bebida (Pequeno, Médio, Grande) */
    private String tamanho;
    /** Indica se a bebida é quente (true) ou fria (false) */
    private boolean quente;
    /** Lista de ingredientes da bebida */
    private List<String> ingredientes;
    
    /**
     * Construtor padrão da classe Bebida.
     * Inicializa com valores padrão.
     */
    public Bebida() {
        super();
        this.tamanho = "Médio";
        this.quente = true;
        this.ingredientes = new ArrayList<>();
    }
    
    /**
     * Construtor com parâmetros da classe Bebida.
     * 
     * @param id Identificador único do produto
     * @param nome Nome do produto
     * @param descricao Descrição do produto
     * @param preco Preço do produto
     * @param categoria Categoria do produto
     * @param tamanho Tamanho da bebida (P, M, G)
     * @param quente Indica se a bebida é quente ou fria
     */
    public Bebida(int id, String nome, String descricao, double preco, String categoria, 
                 String tamanho, boolean quente) {
        super(id, nome, descricao, preco, categoria);
        this.tamanho = tamanho;
        this.quente = quente;
        this.ingredientes = new ArrayList<>();
    }
    
    /**
     * Retorna o tamanho da bebida.
     * 
     * @return Tamanho da bebida
     */
    public String getTamanho() {
        return tamanho;
    }
    
    /**
     * Define o tamanho da bebida.
     * 
     * @param tamanho Novo tamanho da bebida
     */
    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }
    
    /**
     * Verifica se a bebida é quente.
     * 
     * @return true se a bebida for quente, false caso contrário
     */
    public boolean isQuente() {
        return quente;
    }
    
    /**
     * Define se a bebida é quente ou fria.
     * 
     * @param quente true para bebida quente, false para bebida fria
     */
    public void setQuente(boolean quente) {
        this.quente = quente;
    }
    
    /**
     * Retorna a lista de ingredientes da bebida.
     * 
     * @return Lista de ingredientes (cópia defensiva)
     */
    public List<String> getIngredientes() {
        return new ArrayList<>(ingredientes);
    }
    
    /**
     * Adiciona um ingrediente à bebida.
     * 
     * @param ingrediente Ingrediente a ser adicionado
     * @return true se o ingrediente foi adicionado com sucesso
     */
    public boolean adicionarIngrediente(String ingrediente) {
        if (ingrediente != null && !ingrediente.trim().isEmpty()) {
            return ingredientes.add(ingrediente);
        }
        return false;
    }
    
    /**
     * Remove um ingrediente da bebida.
     * 
     * @param ingrediente Ingrediente a ser removido
     * @return true se o ingrediente foi removido com sucesso
     */
    public boolean removerIngrediente(String ingrediente) {
        return ingredientes.remove(ingrediente);
    }
    
    /**
     * Implementação do método abstrato para calcular desconto.
     * Bebidas quentes têm 5% de desconto em dias frios.
     * 
     * @return Valor do desconto a ser aplicado
     */
    @Override
    public double calcularDesconto() {
        // Simulando um dia frio para bebidas quentes
        if (quente) {
            return getPreco() * 0.05; // 5% de desconto
        }
        return 0.0;
    }
    
    /**
     * Sobrescreve o método toString para incluir informações específicas de bebida.
     * 
     * @return String formatada com os dados da bebida
     */
    @Override
    public String toString() {
        String tipoTemperatura = quente ? "Quente" : "Fria";
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append(String.format("\n   Tamanho: %s | %s", tamanho, tipoTemperatura));
        
        if (!ingredientes.isEmpty()) {
            sb.append("\n   Ingredientes: ");
            sb.append(String.join(", ", ingredientes));
        }
        
        return sb.toString();
    }
}
