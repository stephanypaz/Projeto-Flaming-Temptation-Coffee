package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa um alimento no sistema, estendendo a classe abstrata Produto.
 * Armazena informações específicas de alimentos como opções vegetarianas e sem glúten.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 */
public class Alimento extends Produto {
    /** Indica se o alimento é vegetariano */
    private boolean vegetariano;
    /** Indica se o alimento é sem glúten */
    private boolean semGluten;
    /** Lista de alérgenos presentes no alimento */
    private List<String> alergenos;
    
    /**
     * Construtor padrão da classe Alimento.
     * Inicializa com valores padrão.
     */
    public Alimento() {
        super();
        this.vegetariano = false;
        this.semGluten = false;
        this.alergenos = new ArrayList<>();
    }
    
    /**
     * Construtor com parâmetros da classe Alimento.
     * 
     * @param id Identificador único do produto
     * @param nome Nome do produto
     * @param descricao Descrição do produto
     * @param preco Preço do produto
     * @param categoria Categoria do produto
     * @param vegetariano Indica se o alimento é vegetariano
     * @param semGluten Indica se o alimento é sem glúten
     */
    public Alimento(int id, String nome, String descricao, double preco, String categoria, 
                   boolean vegetariano, boolean semGluten) {
        super(id, nome, descricao, preco, categoria);
        this.vegetariano = vegetariano;
        this.semGluten = semGluten;
        this.alergenos = new ArrayList<>();
    }
    
    /**
     * Verifica se o alimento é vegetariano.
     * 
     * @return true se o alimento for vegetariano, false caso contrário
     */
    public boolean isVegetariano() {
        return vegetariano;
    }
    
    /**
     * Define se o alimento é vegetariano.
     * 
     * @param vegetariano true para alimento vegetariano, false caso contrário
     */
    public void setVegetariano(boolean vegetariano) {
        this.vegetariano = vegetariano;
    }
    
    /**
     * Verifica se o alimento é sem glúten.
     * 
     * @return true se o alimento for sem glúten, false caso contrário
     */
    public boolean isSemGluten() {
        return semGluten;
    }
    
    /**
     * Define se o alimento é sem glúten.
     * 
     * @param semGluten true para alimento sem glúten, false caso contrário
     */
    public void setSemGluten(boolean semGluten) {
        this.semGluten = semGluten;
    }
    
    /**
     * Retorna a lista de alérgenos presentes no alimento.
     * 
     * @return Lista de alérgenos (cópia defensiva)
     */
    public List<String> getAlergenos() {
        return new ArrayList<>(alergenos);
    }
    
    /**
     * Adiciona um alérgeno à lista.
     * 
     * @param alergeno Alérgeno a ser adicionado
     * @return true se o alérgeno foi adicionado com sucesso
     */
    public boolean adicionarAlergeno(String alergeno) {
        if (alergeno != null && !alergeno.trim().isEmpty()) {
            return alergenos.add(alergeno);
        }
        return false;
    }
    
    /**
     * Remove um alérgeno da lista.
     * 
     * @param alergeno Alérgeno a ser removido
     * @return true se o alérgeno foi removido com sucesso
     */
    public boolean removerAlergeno(String alergeno) {
        return alergenos.remove(alergeno);
    }
    
    /**
     * Implementação do método abstrato para calcular desconto.
     * Alimentos vegetarianos têm 10% de desconto às segundas-feiras.
     * 
     * @return Valor do desconto a ser aplicado
     */
    @Override
    public double calcularDesconto() {
        // Simulando uma segunda-feira para alimentos vegetarianos
        if (vegetariano) {
            return getPreco() * 0.10; // 10% de desconto
        }
        return 0.0;
    }
    
    /**
     * Sobrescreve o método toString para incluir informações específicas de alimento.
     * 
     * @return String formatada com os dados do alimento
     */
    @Override
    public String toString() {
        StringBuilder info = new StringBuilder(super.toString());
        
        if (vegetariano) {
            info.append("\n   ✓ Vegetariano");
        }
        
        if (semGluten) {
            info.append("\n   ✓ Sem Glúten");
        }
        
        if (!alergenos.isEmpty()) {
            info.append("\n   Contém alérgenos: ");
            info.append(String.join(", ", alergenos));
        }
        
        return info.toString();
    }
}
