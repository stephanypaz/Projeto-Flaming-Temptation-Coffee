package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa um produto genérico no sistema.
 * Serve como base para todos os tipos específicos de produtos.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 */
public abstract class Produto {
    private int id;
    private String nome;
    private String descricao;
    private double preco;
    private String categoria;
    private List<String> tags;
    
    /**
     * Construtor padrão da classe Produto.
     */
    public Produto() {
        this.id = 0;
        this.nome = "";
        this.descricao = "";
        this.preco = 0.0;
        this.categoria = "";
        this.tags = new ArrayList<>();
    }
    
    /**
     * Construtor com parâmetros da classe Produto.
     * 
     * @param id Identificador único do produto
     * @param nome Nome do produto
     * @param descricao Descrição do produto
     * @param preco Preço do produto
     * @param categoria Categoria do produto
     */
    public Produto(int id, String nome, String descricao, double preco, String categoria) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.preco = preco;
        this.categoria = categoria;
        this.tags = new ArrayList<>();
    }
    
    /**
     * Retorna o identificador do produto.
     * 
     * @return Identificador único do produto
     */
    public int getId() {
        return id;
    }
    
    /**
     * Define o identificador do produto.
     * 
     * @param id Novo identificador do produto
     */
    public void setId(int id) {
        this.id = id;
    }
    
    /**
     * Retorna o nome do produto.
     * 
     * @return Nome do produto
     */
    public String getNome() {
        return nome;
    }
    
    /**
     * Define o nome do produto.
     * 
     * @param nome Novo nome do produto
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    /**
     * Retorna a descrição do produto.
     * 
     * @return Descrição do produto
     */
    public String getDescricao() {
        return descricao;
    }
    
    /**
     * Define a descrição do produto.
     * 
     * @param descricao Nova descrição do produto
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    /**
     * Retorna o preço do produto.
     * 
     * @return Preço do produto
     */
    public double getPreco() {
        return preco;
    }
    
    /**
     * Define o preço do produto.
     * 
     * @param preco Novo preço do produto
     */
    public void setPreco(double preco) {
        this.preco = preco;
    }
    
    /**
     * Retorna a categoria do produto.
     * 
     * @return Categoria do produto
     */
    public String getCategoria() {
        return categoria;
    }
    
    /**
     * Define a categoria do produto.
     * 
     * @param categoria Nova categoria do produto
     */
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    /**
     * Retorna as tags associadas ao produto.
     * 
     * @return Lista de tags do produto
     */
    public List<String> getTags() {
        return new ArrayList<>(tags); // Retorna uma cópia para evitar modificação externa
    }
    
    /**
     * Adiciona uma tag ao produto.
     * 
     * @param tag Tag a ser adicionada
     * @return true se a tag foi adicionada com sucesso
     */
    public boolean adicionarTag(String tag) {
        if (tag != null && !tag.trim().isEmpty() && !tags.contains(tag)) {
            return tags.add(tag);
        }
        return false;
    }
    
    /**
     * Remove uma tag do produto.
     * 
     * @param tag Tag a ser removida
     * @return true se a tag foi removida com sucesso
     */
    public boolean removerTag(String tag) {
        return tags.remove(tag);
    }
    
    /**
     * Método abstrato para calcular possíveis descontos específicos por tipo de produto.
     * Deve ser implementado pelas subclasses.
     * 
     * @return Valor do desconto a ser aplicado
     */
    public abstract double calcularDesconto();
    
    /**
     * Retorna uma representação textual do produto.
     * 
     * @return String formatada com os dados do produto
     */
    @Override
    public String toString() {
        return String.format("%d. %s - R$ %.2f\n   %s", id, nome, preco, descricao);
    }
    
    /**
     * Retorna uma representação textual simplificada do produto.
     * 
     * @return String formatada com os dados simplificados do produto
     */
    public String toStringSimples() {
        return String.format("%s - R$ %.2f", nome, preco);
    }
}
