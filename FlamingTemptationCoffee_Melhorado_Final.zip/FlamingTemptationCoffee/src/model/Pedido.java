package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Classe que representa um pedido no sistema.
 * Armazena informações sobre os itens pedidos, cliente e status.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 */
public class Pedido {
    private int numeroPedido;
    private List<ItemPedido> itens;
    private String nomeCliente;
    private String status;
    private String formaPagamento;
    private Map<String, String> dadosPagamento;
    private List<String> observacoes;
    private String dataHora;
    
    /**
     * Construtor padrão da classe Pedido.
     */
    public Pedido() {
        this.numeroPedido = 0;
        this.itens = new ArrayList<>();
        this.nomeCliente = "";
        this.status = "Novo";
        this.formaPagamento = "";
        this.dadosPagamento = new HashMap<>();
        this.observacoes = new ArrayList<>();
        this.dataHora = "";
    }
    
    /**
     * Construtor com parâmetros da classe Pedido.
     * 
     * @param numeroPedido Número único do pedido
     * @param itens Lista de itens do pedido
     * @param nomeCliente Nome do cliente
     * @param formaPagamento Forma de pagamento escolhida
     * @param dataHora Data e hora do pedido
     */
    public Pedido(int numeroPedido, List<ItemPedido> itens, String nomeCliente, 
                 String formaPagamento, String dataHora) {
        this.numeroPedido = numeroPedido;
        this.itens = new ArrayList<>(itens); // Cria uma cópia da lista
        this.nomeCliente = nomeCliente;
        this.status = "Novo";
        this.formaPagamento = formaPagamento;
        this.dadosPagamento = new HashMap<>();
        this.observacoes = new ArrayList<>();
        this.dataHora = dataHora;
    }
    
    /**
     * Retorna o número do pedido.
     * 
     * @return Número do pedido
     */
    public int getNumeroPedido() {
        return numeroPedido;
    }
    
    /**
     * Define o número do pedido.
     * 
     * @param numeroPedido Novo número do pedido
     */
    public void setNumeroPedido(int numeroPedido) {
        this.numeroPedido = numeroPedido;
    }
    
    /**
     * Retorna a lista de itens do pedido.
     * 
     * @return Lista de itens do pedido
     */
    public List<ItemPedido> getItens() {
        return new ArrayList<>(itens); // Retorna uma cópia para evitar modificação externa
    }
    
    /**
     * Define a lista de itens do pedido.
     * 
     * @param itens Nova lista de itens
     */
    public void setItens(List<ItemPedido> itens) {
        this.itens = new ArrayList<>(itens); // Cria uma cópia da lista
    }
    
    /**
     * Adiciona um item ao pedido.
     * 
     * @param item Item a ser adicionado
     * @return true se o item foi adicionado com sucesso
     */
    public boolean adicionarItem(ItemPedido item) {
        if (item != null) {
            return itens.add(item);
        }
        return false;
    }
    
    /**
     * Remove um item do pedido pelo índice.
     * 
     * @param indice Índice do item a ser removido
     * @return Item removido ou null se índice inválido
     */
    public ItemPedido removerItem(int indice) {
        if (indice >= 0 && indice < itens.size()) {
            return itens.remove(indice);
        }
        return null;
    }
    
    /**
     * Retorna o nome do cliente.
     * 
     * @return Nome do cliente
     */
    public String getNomeCliente() {
        return nomeCliente;
    }
    
    /**
     * Define o nome do cliente.
     * 
     * @param nomeCliente Novo nome do cliente
     */
    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }
    
    /**
     * Retorna o status atual do pedido.
     * 
     * @return Status do pedido
     */
    public String getStatus() {
        return status;
    }
    
    /**
     * Define o status do pedido.
     * 
     * @param status Novo status do pedido
     */
    public void setStatus(String status) {
        this.status = status;
    }
    
    /**
     * Retorna a forma de pagamento.
     * 
     * @return Forma de pagamento
     */
    public String getFormaPagamento() {
        return formaPagamento;
    }
    
    /**
     * Define a forma de pagamento.
     * 
     * @param formaPagamento Nova forma de pagamento
     */
    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }
    
    /**
     * Retorna os dados de pagamento.
     * 
     * @return Mapa com dados de pagamento
     */
    public Map<String, String> getDadosPagamento() {
        return new HashMap<>(dadosPagamento); // Retorna uma cópia para evitar modificação externa
    }
    
    /**
     * Adiciona um dado de pagamento.
     * 
     * @param chave Chave do dado
     * @param valor Valor do dado
     */
    public void adicionarDadoPagamento(String chave, String valor) {
        if (chave != null && !chave.trim().isEmpty()) {
            dadosPagamento.put(chave, valor);
        }
    }
    
    /**
     * Retorna a lista de observações do pedido.
     * 
     * @return Lista de observações
     */
    public List<String> getObservacoes() {
        return new ArrayList<>(observacoes); // Retorna uma cópia para evitar modificação externa
    }
    
    /**
     * Adiciona uma observação ao pedido.
     * 
     * @param observacao Observação a ser adicionada
     * @return true se a observação foi adicionada com sucesso
     */
    public boolean adicionarObservacao(String observacao) {
        if (observacao != null && !observacao.trim().isEmpty()) {
            return observacoes.add(observacao);
        }
        return false;
    }
    
    /**
     * Retorna a data e hora do pedido.
     * 
     * @return Data e hora do pedido
     */
    public String getDataHora() {
        return dataHora;
    }
    
    /**
     * Define a data e hora do pedido.
     * 
     * @param dataHora Nova data e hora
     */
    public void setDataHora(String dataHora) {
        this.dataHora = dataHora;
    }
    
    /**
     * Calcula o valor total do pedido.
     * 
     * @return Valor total do pedido
     */
    public double calcularTotal() {
        double total = 0.0;
        for (ItemPedido item : itens) {
            total += item.calcularSubtotal();
        }
        return total;
    }
    
    /**
     * Retorna uma representação textual do pedido.
     * 
     * @return String formatada com os dados do pedido
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Pedido #%d - %s\n", numeroPedido, dataHora));
        sb.append(String.format("Cliente: %s\n", nomeCliente));
        sb.append(String.format("Status: %s\n", status));
        sb.append(String.format("Forma de Pagamento: %s\n\n", formaPagamento));
        
        sb.append("Itens:\n");
        for (int i = 0; i < itens.size(); i++) {
            sb.append(String.format("%d. %s\n", (i + 1), itens.get(i).toString()));
        }
        
        sb.append(String.format("\nTotal: R$ %.2f", calcularTotal()));
        
        if (!observacoes.isEmpty()) {
            sb.append("\n\nObservações:\n");
            for (String obs : observacoes) {
                sb.append("- ").append(obs).append("\n");
            }
        }
        
        return sb.toString();
    }
}
