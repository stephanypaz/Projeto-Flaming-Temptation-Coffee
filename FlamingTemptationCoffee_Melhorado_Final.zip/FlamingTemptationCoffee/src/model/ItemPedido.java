package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa um item de pedido no sistema.
 * Associa um produto a uma quantidade e observações específicas.
 * 
 * @author Flaming Temptation Coffee Team
 * @version 1.1
 * @since 1.0
 */
public class ItemPedido {
    /** Produto associado ao item */
    private Produto produto;
    /** Quantidade do produto */
    private int quantidade;
    /** Observações sobre o item */
    private String observacoes;
    /** Lista de personalizações aplicadas ao item */
    private List<String> personalizacoes;
    
    /**
     * Construtor padrão da classe ItemPedido.
     */
    public ItemPedido() {
        this.produto = null;
        this.quantidade = 0;
        this.observacoes = "";
        this.personalizacoes = new ArrayList<>();
    }
    
    /**
     * Construtor com parâmetros da classe ItemPedido.
     * 
     * @param produto Produto associado ao item
     * @param quantidade Quantidade do produto
     * @param observacoes Observações sobre o item
     */
    public ItemPedido(Produto produto, int quantidade, String observacoes) {
        this.produto = produto;
        this.quantidade = quantidade;
        this.observacoes = observacoes;
        this.personalizacoes = new ArrayList<>();
    }
    
    /**
     * Retorna o produto associado ao item.
     * 
     * @return Produto associado
     */
    public Produto getProduto() {
        return produto;
    }
    
    /**
     * Define o produto associado ao item.
     * 
     * @param produto Novo produto
     */
    public void setProduto(Produto produto) {
        this.produto = produto;
    }
    
    /**
     * Retorna a quantidade do produto.
     * 
     * @return Quantidade do produto
     */
    public int getQuantidade() {
        return quantidade;
    }
    
    /**
     * Define a quantidade do produto.
     * 
     * @param quantidade Nova quantidade
     */
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    
    /**
     * Retorna as observações sobre o item.
     * 
     * @return Observações sobre o item
     */
    public String getObservacoes() {
        return observacoes;
    }
    
    /**
     * Define as observações sobre o item.
     * 
     * @param observacoes Novas observações
     */
    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }
    
    /**
     * Retorna a lista de personalizações aplicadas ao item.
     * 
     * @return Lista de personalizações (cópia defensiva)
     */
    public List<String> getPersonalizacoes() {
        return new ArrayList<>(personalizacoes);
    }
    
    /**
     * Adiciona uma personalização ao item.
     * 
     * @param personalizacao Personalização a ser adicionada
     * @return true se a personalização foi adicionada com sucesso
     */
    public boolean adicionarPersonalizacao(String personalizacao) {
        if (personalizacao != null && !personalizacao.trim().isEmpty()) {
            return personalizacoes.add(personalizacao);
        }
        return false;
    }
    
    /**
     * Remove uma personalização do item.
     * 
     * @param personalizacao Personalização a ser removida
     * @return true se a personalização foi removida com sucesso
     */
    public boolean removerPersonalizacao(String personalizacao) {
        return personalizacoes.remove(personalizacao);
    }
    
    /**
     * Calcula o subtotal do item (preço do produto * quantidade).
     * 
     * @return Valor do subtotal
     */
    public double calcularSubtotal() {
        if (produto == null) {
            return 0.0;
        }
        return produto.getPreco() * quantidade;
    }
    
    /**
     * Retorna uma representação textual do item de pedido.
     * 
     * @return String formatada com os dados do item
     */
    @Override
    public String toString() {
        if (produto == null) {
            return "Item inválido";
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s x%d - R$ %.2f", produto.getNome(), quantidade, calcularSubtotal()));
        
        if (observacoes != null && !observacoes.trim().isEmpty()) {
            sb.append(String.format("\n   Obs: %s", observacoes));
        }
        
        if (!personalizacoes.isEmpty()) {
            sb.append("\n   Personalizações:");
            for (String personalizacao : personalizacoes) {
                sb.append("\n   - ").append(personalizacao);
            }
        }
        
        return sb.toString();
    }
}
